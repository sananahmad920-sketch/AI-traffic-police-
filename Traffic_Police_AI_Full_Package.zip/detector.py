"""
Optimized Object Detection & Tracking Wrapper for CPU / GPU.
Includes cached model loading support for zero redundant disk I/O.
Core YOLO detection logic and weights remain untouched.
"""
from typing import Dict, List, Tuple, Any
import torch
import numpy as np
from ultralytics import YOLO
import config

_MODEL_CACHE: Dict[str, YOLO] = {}

def get_shared_yolo_model(model_name: str = config.MODEL_NAME) -> YOLO:
    """Loads YOLO model once and caches in memory across pipeline instances."""
    global _MODEL_CACHE
    if model_name not in _MODEL_CACHE:
        print(f"[Detector] Loading and caching YOLO model: {model_name}...")
        _MODEL_CACHE[model_name] = YOLO(model_name)
    return _MODEL_CACHE[model_name]

class TrafficDetector:
    def __init__(
        self,
        model_name: str = config.MODEL_NAME,
        conf_threshold: float = config.CONFIDENCE_THRESHOLD,
        imgsz: int = 480,
        shared_model: YOLO = None
    ):
        self.model = shared_model if shared_model is not None else get_shared_yolo_model(model_name)
        self.conf_threshold = conf_threshold
        self.imgsz = imgsz
        self.allowed_classes = [0, 2, 3, 5, 7, 9]

        # Optimize PyTorch for multi-core CPU inference
        if not torch.cuda.is_available():
            try:
                torch.set_num_threads(4)
            except Exception:
                pass

    def set_imgsz(self, imgsz: int):
        self.imgsz = imgsz

    def process_frame(self, frame: np.ndarray) -> Dict[str, Any]:
        """
        Runs tracking on a single frame with optimized input size.
        """
        results = self.model.track(
            source=frame,
            persist=True,
            classes=self.allowed_classes,
            conf=self.conf_threshold,
            imgsz=self.imgsz,
            verbose=False,
            tracker="bytetrack.yaml"
        )

        vehicles = []
        persons = []
        traffic_lights = []

        if results and len(results) > 0 and results[0].boxes is not None:
            boxes = results[0].boxes
            for i in range(len(boxes)):
                cls_id = int(boxes.cls[i].item())
                conf = float(boxes.conf[i].item())
                xyxy = boxes.xyxy[i].cpu().numpy().astype(int)
                bbox = (int(xyxy[0]), int(xyxy[1]), int(xyxy[2]), int(xyxy[3]))

                track_id = int(boxes.id[i].item()) if boxes.id is not None and boxes.id[i] is not None else -1

                if cls_id in config.VEHICLE_CLASSES:
                    vehicles.append({
                        "track_id": track_id,
                        "class_id": cls_id,
                        "class_name": config.VEHICLE_CLASSES[cls_id],
                        "bbox": bbox,
                        "conf": conf
                    })
                elif cls_id == 0:
                    persons.append((track_id, bbox))
                elif cls_id == 9:
                    traffic_lights.append({
                        "bbox": bbox,
                        "conf": conf
                    })

        return {
            "vehicles": vehicles,
            "persons": persons,
            "traffic_lights": traffic_lights
        }
