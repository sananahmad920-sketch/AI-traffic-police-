"""
Hardened, Memory-Safe Evidence Manager & Police Challan Logging.
Computes SHA-256 tamper-evident hash for each captured evidence image/video,
persists records to PostgreSQL database, and maintains fallback CSV.
"""
import os
import csv
import gc
import hashlib
import threading
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
import cv2
import numpy as np

from logger import get_logger
from database import db

logger = get_logger("EvidenceLogger")

def compute_sha256(file_path: str) -> str:
    """Computes SHA-256 cryptographic hash of a file for tamper-evidence."""
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(65536), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()

class EvidenceLogger:
    def __init__(self, output_dir: Path, max_memory_records: int = 30):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.csv_file = self.output_dir / "violations.csv"
        self.max_memory_records = max_memory_records
        self._lock = threading.Lock()
        self._init_csv()
        self.recent_violations: List[dict] = []

    def _init_csv(self):
        with self._lock:
            if not self.csv_file.exists():
                with open(self.csv_file, mode="w", newline="", encoding="utf-8") as f:
                    writer = csv.writer(f)
                    writer.writerow([
                        "violation_id",
                        "timestamp",
                        "date",
                        "time",
                        "camera_id",
                        "track_id",
                        "vehicle_type",
                        "plate_number",
                        "violation_type",
                        "detail",
                        "speed_kmh",
                        "evidence_image",
                        "sha256_hash"
                    ])

    def log_violation(
        self,
        frame: np.ndarray,
        track_id: int,
        vehicle_type: str,
        plate_number: str,
        violation_type: str,
        detail: str,
        bbox: tuple,
        speed_kmh: float = 0.0,
        camera_id: str = "CAM-01"
    ) -> dict:
        """
        Annotates snapshot, compresses to JPEG, computes SHA-256 hash at capture time,
        and saves record into PostgreSQL and fallback CSV.
        """
        now = datetime.now()
        timestamp_str = now.strftime("%Y-%m-%d %H:%M:%S")
        date_str = now.strftime("%Y-%m-%d")
        time_str = now.strftime("%H:%M:%S")
        file_ts = now.strftime("%Y%m%d_%H%M%S_%f")[:19]

        violation_id = f"VIOL-{file_ts}-{camera_id}-{track_id}"
        image_filename = f"{violation_id}.jpg"
        image_path = self.output_dir / image_filename

        # Generate Evidence Card
        card = self._create_evidence_image(
            frame=frame,
            bbox=bbox,
            violation_id=violation_id,
            violation_type=violation_type,
            plate_number=plate_number,
            vehicle_type=vehicle_type,
            speed_kmh=speed_kmh,
            timestamp_str=timestamp_str,
            camera_id=camera_id
        )

        # Write image with optimized JPEG quality
        cv2.imwrite(str(image_path), card, [int(cv2.IMWRITE_JPEG_QUALITY), 85])
        del card  # Free memory immediately

        # Compute tamper-evident cryptographic hash at capture time
        evidence_hash = compute_sha256(str(image_path))

        record = {
            "violation_id": violation_id,
            "timestamp": timestamp_str,
            "date": date_str,
            "time": time_str,
            "camera_id": camera_id,
            "track_id": track_id,
            "vehicle_type": vehicle_type,
            "plate_number": plate_number,
            "violation_type": violation_type,
            "detail": detail,
            "speed_kmh": speed_kmh,
            "evidence_image": str(image_path),
            "filename": image_filename,
            "sha256_hash": evidence_hash
        }

        # 1. Insert into PostgreSQL / Database
        db.insert_violation(record)

        # 2. Append to fallback CSV with lock
        with self._lock:
            with open(self.csv_file, mode="a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow([
                    record["violation_id"],
                    record["timestamp"],
                    record["date"],
                    record["time"],
                    record["camera_id"],
                    record["track_id"],
                    record["vehicle_type"],
                    record["plate_number"],
                    record["violation_type"],
                    record["detail"],
                    record["speed_kmh"],
                    record["evidence_image"],
                    record["sha256_hash"]
                ])

            self.recent_violations.insert(0, record)
            # Enforce bounded memory size
            if len(self.recent_violations) > self.max_memory_records:
                self.recent_violations = self.recent_violations[:self.max_memory_records]

        logger.info(f"Evidence captured: {violation_id} from {camera_id} (SHA256: {evidence_hash[:16]}...)")
        return record

    def _create_evidence_image(
        self,
        frame: np.ndarray,
        bbox: tuple,
        violation_id: str,
        violation_type: str,
        plate_number: str,
        vehicle_type: str,
        speed_kmh: float,
        timestamp_str: str,
        camera_id: str = "CAM-01"
    ) -> np.ndarray:
        """
        Generates official police evidence snapshot with vehicle crop and banner.
        Bounds-checked to prevent out-of-bounds indexing.
        """
        h, w = frame.shape[:2]
        x1 = max(0, min(w - 1, int(bbox[0])))
        y1 = max(0, min(h - 1, int(bbox[1])))
        x2 = max(x1 + 1, min(w, int(bbox[2])))
        y2 = max(y1 + 1, min(h, int(bbox[3])))

        pad = 25
        crop_x1 = max(0, x1 - pad)
        crop_y1 = max(0, y1 - pad)
        crop_x2 = min(w, x2 + pad)
        crop_y2 = min(h, y2 + pad)

        vehicle_crop = frame[crop_y1:crop_y2, crop_x1:crop_x2].copy()

        # Draw red highlight box on cropped vehicle
        box_in_crop_x1 = max(0, x1 - crop_x1)
        box_in_crop_y1 = max(0, y1 - crop_y1)
        box_in_crop_x2 = min(vehicle_crop.shape[1], x2 - crop_x1)
        box_in_crop_y2 = min(vehicle_crop.shape[0], y2 - crop_y1)
        cv2.rectangle(vehicle_crop, (box_in_crop_x1, box_in_crop_y1), (box_in_crop_x2, box_in_crop_y2), (0, 0, 255), 2)

        target_h = 280
        aspect = vehicle_crop.shape[1] / max(vehicle_crop.shape[0], 1)
        target_w = max(int(target_h * aspect), 260)
        resized_crop = cv2.resize(vehicle_crop, (target_w, target_h))

        card_w = target_w + 340
        card_h = target_h + 60
        card = np.zeros((card_h, card_w, 3), dtype=np.uint8)
        card[:] = (32, 34, 38)

        # Header banner
        cv2.rectangle(card, (0, 0), (card_w, 50), (0, 0, 180), -1)
        cv2.putText(card, f"TRAFFIC VIOLATION: {violation_type}", (15, 33),
                    cv2.FONT_HERSHEY_DUPLEX, 0.65, (255, 255, 255), 2)

        card[55:55+target_h, 10:10+target_w] = resized_crop

        info_x = target_w + 25
        lines = [
            ("CAMERA ID:", camera_id),
            ("VIOLATION ID:", violation_id),
            ("DATE / TIME:", timestamp_str),
            ("VEHICLE TYPE:", vehicle_type.upper()),
            ("PLATE NUMBER:", plate_number),
            ("RECORDED SPEED:", f"{speed_kmh} km/h" if speed_kmh > 0 else "N/A"),
            ("HASH SECURITY:", "SHA-256 VERIFIED")
        ]

        curr_y = 75
        for label, val in lines:
            cv2.putText(card, label, (info_x, curr_y), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (160, 160, 160), 1)
            color = (0, 255, 255) if "PLATE" in label else ((0, 255, 0) if "HASH" in label else (255, 255, 255))
            cv2.putText(card, val, (info_x, curr_y + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.52, color, 1, cv2.LINE_AA)
            curr_y += 33

        return card
