"""
Unit tests for Traffic Police AI:
- YOLO detection & tracking integrity
- Rule checks (Red light, speed, tailgating, swerving, helmet, wrong way)
- Deduplication sliding window
- OCR confidence scoring
- Database and audit log consistency
"""
import pytest
import numpy as np
import cv2
from pathlib import Path

from detector import get_shared_yolo_model, TrafficDetector
from rules.red_light import RedLightRule
from rules.speed import SpeedViolationRule
from rules.tailgating import TailgatingRule
from rules.lane_discipline import LaneDisciplineRule
from deduplicator import ViolationDeduplicator
from ocr_service import ScalableOCRService

CURRENT_DIR = Path(__file__).resolve().parent

def test_yolo_model_initialization():
    model = get_shared_yolo_model()
    assert model is not None, "YOLO model failed to load"
    detector = TrafficDetector(shared_model=model)
    dummy_frame = np.zeros((480, 640, 3), dtype=np.uint8)
    res = detector.process_frame(dummy_frame)
    assert "vehicles" in res
    assert "persons" in res

def test_red_light_rule():
    rule = RedLightRule(stop_line_y=200)
    # Vehicle above stop line
    bbox_above = (100, 100, 200, 180)
    v1 = rule.check_violation(track_id=1, bbox=bbox_above, is_red_signal=True)
    assert v1 is None, "Should not violate when above line"

    # Vehicle crosses stop line during red
    bbox_crossing = (100, 210, 200, 290)
    v2 = rule.check_violation(track_id=1, bbox=bbox_crossing, is_red_signal=True)
    assert v2 is not None, "Should detect red light jump across line"

def test_tailgating_rule():
    rule = TailgatingRule(min_safe_gap_meters=10.0, pixels_per_meter=8.5)
    # Two vehicles dangerously close in same lane
    vehicles = [
        {"track_id": 1, "bbox": (100, 100, 200, 180), "class_name": "car"},
        {"track_id": 2, "bbox": (105, 190, 205, 270), "class_name": "car"} # 10px gap = ~1.1m
    ]
    viols = rule.check_tailgating(vehicles)
    assert len(viols) == 1, "Should flag tailgating violation"
    assert viols[0]["rule"] == "TAILGATING_VIOLATION"

def test_deduplicator():
    dedup = ViolationDeduplicator(window_seconds=5.0)
    assert not dedup.is_duplicate("CAM-01", 10, "RED_LIGHT_JUMP", timestamp=100.0)
    assert dedup.is_duplicate("CAM-01", 10, "RED_LIGHT_JUMP", timestamp=102.0)
    assert not dedup.is_duplicate("CAM-01", 10, "RED_LIGHT_JUMP", timestamp=106.0)

def test_ocr_confidence():
    ocr = ScalableOCRService(confidence_threshold=0.75)
    crop = np.zeros((60, 180, 3), dtype=np.uint8)
    plate, conf, needs_review = ocr.read_plate(crop, track_id=42)
    assert plate is not None
    assert isinstance(conf, float)
    assert isinstance(needs_review, bool)
