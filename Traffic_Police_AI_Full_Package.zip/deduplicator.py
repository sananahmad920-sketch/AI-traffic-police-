"""
Deduplication Engine for Consecutive Violation Detections.
Prevents the same vehicle violating a rule in consecutive video frames
from generating duplicate fines and database entries.
Uses an in-memory sliding time window with automatic cleanup.
"""
import time
from typing import Dict, Tuple

class ViolationDeduplicator:
    def __init__(self, window_seconds: float = 10.0):
        self.window_seconds = window_seconds
        # Key: (camera_id, track_id, violation_type) -> timestamp
        self._history: Dict[Tuple[str, int, str], float] = {}

    def is_duplicate(self, camera_id: str, track_id: int, violation_type: str, timestamp: float = None) -> bool:
        if track_id == -1:
            return False
            
        now = timestamp or time.time()
        self._cleanup(now)
        
        key = (camera_id, track_id, violation_type)
        if key in self._history:
            last_seen = self._history[key]
            if now - last_seen < self.window_seconds:
                return True
        
        self._history[key] = now
        return False

    def _cleanup(self, now: float):
        if len(self._history) > 2000:
            expired_keys = [k for k, t in self._history.items() if now - t > self.window_seconds]
            for k in expired_keys:
                self._history.pop(k, None)

deduplicator = ViolationDeduplicator(window_seconds=10.0)
