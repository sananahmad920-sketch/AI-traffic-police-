"""
Verification script for upgraded enterprise features:
1. Database insertion with SHA-256 hash
2. Authentication verification with bcrypt
3. Multi-camera worker thread launch and frame capture
4. Audit log recording
"""
import sys
from pathlib import Path
import numpy as np

CURRENT_DIR = Path(__file__).resolve().parent
if str(CURRENT_DIR) not in sys.path:
    sys.path.append(str(CURRENT_DIR))

from logger import get_logger
from database import db
from auth import auth_manager, hash_password, verify_password
from camera_manager import camera_manager
from evidence import EvidenceLogger, compute_sha256

logger = get_logger("SystemVerifier")

def verify_all():
    print("=" * 65)
    print("      VERIFYING UPGRADED ENTERPRISE INFRASTRUCTURE")
    print("=" * 65)

    # 1. Test Auth
    print("[1/4] Testing Authentication & Password Hashing...")
    success, user = auth_manager.authenticate("admin", "policeadmin123")
    assert success, "Admin authentication failed!"
    print("  [OK] Admin authenticated successfully:", user['name'], f"(Role: {user['role']})")

    fail_success, _ = auth_manager.authenticate("admin", "wrongpassword")
    assert not fail_success, "Failed auth should not succeed!"
    print("  [OK] Bad password correctly rejected and logged to audit trail.")

    # 2. Test Multi-Camera Worker Threads
    print("[2/4] Testing Multi-Camera Thread Worker with Reconnection...")
    test_video = str(CURRENT_DIR / "traffic_cctv.mp4")
    worker = camera_manager.add_camera("TEST-CAM-01", test_video, location_name="Test North Junction")
    import time
    time.sleep(1.5)
    is_conn, frame, ts = worker.get_latest_frame()
    assert is_conn and frame is not None, "Worker failed to capture frame from stream!"
    print(f"  [OK] Camera worker running in background thread. Frame size: {frame.shape}, Total read: {worker.total_frames_read}")

    # 3. Test Evidence Capture with SHA-256 and DB Storage
    print("[3/4] Testing Tamper-Evident SHA-256 Storage & DB Insertion...")
    evidence_logger = EvidenceLogger(CURRENT_DIR / "violations")
    rec = evidence_logger.log_violation(
        frame=frame,
        track_id=99,
        vehicle_type="car",
        plate_number="POLICE-TEST-01",
        violation_type="RED_LIGHT_JUMP",
        detail="Test violation for integrity check",
        bbox=(50, 50, 200, 200),
        speed_kmh=48.5,
        camera_id="TEST-CAM-01"
    )
    assert "sha256_hash" in rec and len(rec["sha256_hash"]) == 64, "SHA-256 hash not generated properly!"
    print(f"  [OK] Evidence card written: {rec['violation_id']}")
    print(f"  [OK] Cryptographic SHA-256 Hash: {rec['sha256_hash']}")

    # Verify DB query
    records = db.get_violations(limit=5, camera_id="TEST-CAM-01")
    assert len(records) > 0, "Violation not persisted in database!"
    assert records[0]["sha256_hash"] == rec["sha256_hash"], "Stored hash mismatch!"
    print(f"  [OK] Database query confirmed record in DB with identical SHA-256 hash.")

    # 4. Test Audit Trail
    print("[4/4] Testing Security Audit Trail...")
    auth_manager.log_evidence_access("admin", rec["violation_id"], action="VIEW_EVIDENCE")
    audits = db.get_audit_logs(limit=5)
    assert len(audits) > 0, "No audit logs found in database!"
    print(f"  [OK] Verified {len(audits)} audit logs present. Latest: [{audits[0]['timestamp']}] User: {audits[0]['user_id']} -> {audits[0]['action']}")

    # Clean up test worker
    camera_manager.remove_camera("TEST-CAM-01")
    print("=" * 65)
    print("[OK] ALL ENTERPRISE UPGRADE VERIFICATION CHECKS PASSED!")
    print("=" * 65)

if __name__ == "__main__":
    verify_all()
