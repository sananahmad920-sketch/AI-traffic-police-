"""
Verification test script for the Traffic Violation Detection Pipeline.
Processes the first 60 frames of sample_traffic.mp4 and validates output.
"""
import sys
from pathlib import Path
import cv2

CURRENT_DIR = Path(__file__).resolve().parent
if str(CURRENT_DIR) not in sys.path:
    sys.path.append(str(CURRENT_DIR))

import config
from processor import TrafficViolationProcessor

def test_pipeline():
    print("[1/4] Initializing TrafficViolationProcessor...")
    # Using light settings for fast test
    proc = TrafficViolationProcessor(
        speed_limit_kmh=40.0,
        stop_line_y=250,
        enable_ocr=False # fast test without OCR download delays
    )
    # Force signal to RED to test red-light violation trigger
    proc.set_signal_state(config.SIGNAL_RED)

    video_path = CURRENT_DIR / "traffic_cctv.mp4"
    print(f"[2/4] Opening video file: {video_path}")
    cap = cv2.VideoCapture(str(video_path))
    assert cap.isOpened(), "Could not open sample_traffic.mp4"

    print("[3/4] Processing 80 frames...")
    frame_count = 0
    violations_detected = 0

    while frame_count < 80:
        ret, frame = cap.read()
        if not ret:
            break
        frame_count += 1
        annotated_frame, new_viols = proc.process_frame(frame)
        if new_viols:
            violations_detected += len(new_viols)
            print(f"  --> Frame {frame_count}: Caught {len(new_viols)} violation(s)! Type: {new_viols[0]['violation_type']}")

    cap.release()

    print(f"[4/4] Summary:")
    print(f"  Frames processed: {frame_count}")
    print(f"  Total vehicles tracked: {len(proc.total_vehicles_counted)}")
    print(f"  Total violations logged: {proc.total_violations_count}")
    print(f"  Evidence CSV exists: {config.DATABASE_FILE.exists()}")

    assert frame_count > 0, "No frames processed"
    print("\n✅ PIPELINE TEST PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    test_pipeline()
