"""
Full Stress Test & Benchmark for the Traffic Violation Detection System.
Processes 150 frames, measures FPS, tracks memory stability, and validates output.
"""
import time
import psutil
import cv2
from pathlib import Path
import config
from processor import TrafficViolationProcessor

def run_stress_test():
    print("=" * 65)
    print("      SMART TRAFFIC POLICE AI: 150-FRAME STRESS & LEAK TEST")
    print("=" * 65)

    proc_mem_start = psutil.Process().memory_info().rss / (1024 * 1024)
    print(f"[*] Initial Process Memory: {proc_mem_start:.1f} MB")

    processor = TrafficViolationProcessor(
        speed_limit_kmh=40.0,
        stop_line_y=250,
        imgsz=384,
        frame_skip=3,
        enable_ocr=True
    )
    processor.set_signal_state(config.SIGNAL_RED)

    video_path = Path("traffic_cctv.mp4")
    assert video_path.exists(), "traffic_cctv.mp4 not found"

    cap = cv2.VideoCapture(str(video_path))
    assert cap.isOpened(), "Could not open video file"

    frame_count = 0
    t0 = time.time()

    while frame_count < 150:
        ret, frame = cap.read()
        if not ret:
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            continue
        frame_count += 1

        fh, fw = frame.shape[:2]
        scale = 640 / fw
        frame_res = cv2.resize(frame, (640, int(fh * scale)))

        annotated, new_viols = processor.process_frame(frame_res)

        if frame_count % 30 == 0:
            cur_mem = psutil.Process().memory_info().rss / (1024 * 1024)
            cur_elapsed = time.time() - t0
            cur_fps = frame_count / max(cur_elapsed, 0.01)
            print(f"  --> Frame {frame_count:3d}/150 | FPS: {cur_fps:4.1f} | Memory: {cur_mem:5.1f} MB | Tracked: {len(processor.total_vehicles_counted)} | Violations: {processor.total_violations_count}")

    cap.release()
    total_time = time.time() - t0
    final_fps = frame_count / max(total_time, 0.01)
    proc_mem_end = psutil.Process().memory_info().rss / (1024 * 1024)

    print("-" * 65)
    print(f"[✓] Total Frames Processed: {frame_count}")
    print(f"[✓] Total Processing Time: {total_time:.2f} s")
    print(f"[✓] Average Throughput: {final_fps:.1f} FPS")
    print(f"[✓] Memory Growth: {proc_mem_end - proc_mem_start:+.1f} MB (End: {proc_mem_end:.1f} MB)")
    print(f"[✓] Violations Caught: {processor.total_violations_count}")
    print(f"[✓] Database Exists: {config.DATABASE_FILE.exists()}")
    print("=" * 65)
    print("✅ STRESS & LEAK TEST COMPLETED SUCCESSFULLY!")

if __name__ == "__main__":
    run_stress_test()
