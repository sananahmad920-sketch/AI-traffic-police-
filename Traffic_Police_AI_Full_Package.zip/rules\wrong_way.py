"""
Hardened Wrong-Way Driving Rule with Bounded Memory.
"""
from typing import Dict, Tuple, Optional

class WrongWayRule:
    def __init__(self, allowed_direction: str = "down", min_displacement_px: float = 35.0, max_cached_ids: int = 1000):
        self.allowed_direction = allowed_direction
        self.min_displacement_px = min_displacement_px
        self.max_cached_ids = max_cached_ids
        self.initial_positions: Dict[int, Tuple[float, float]] = {}
        self.penalized_ids = set()

    def update_direction(self, direction: str):
        self.allowed_direction = direction

    def _prune_cache_if_needed(self):
        if len(self.initial_positions) > self.max_cached_ids:
            old_keys = list(self.initial_positions.keys())[:int(self.max_cached_ids * 0.3)]
            for k in old_keys:
                self.initial_positions.pop(k, None)
                self.penalized_ids.discard(k)

    def check_violation(
        self,
        track_id: int,
        bbox: Tuple[int, int, int, int]
    ) -> Optional[dict]:
        if track_id in self.penalized_ids:
            return None

        self._prune_cache_if_needed()

        x1, y1, x2, y2 = bbox
        cx = (x1 + x2) / 2.0
        cy = (y1 + y2) / 2.0

        if track_id not in self.initial_positions:
            self.initial_positions[track_id] = (cx, cy)
            return None

        start_x, start_y = self.initial_positions[track_id]
        dy = cy - start_y
        dx = cx - start_x

        is_wrong_way = False
        if self.allowed_direction == "down" and dy < -self.min_displacement_px:
            is_wrong_way = True
        elif self.allowed_direction == "up" and dy > self.min_displacement_px:
            is_wrong_way = True
        elif self.allowed_direction == "right" and dx < -self.min_displacement_px:
            is_wrong_way = True
        elif self.allowed_direction == "left" and dx > self.min_displacement_px:
            is_wrong_way = True

        if is_wrong_way:
            self.penalized_ids.add(track_id)
            return {
                "rule": "WRONG_WAY_VIOLATION",
                "detail": f"Vehicle moving against allowed direction ({self.allowed_direction.upper()})",
                "track_id": track_id,
                "bbox": bbox
            }

        return None
