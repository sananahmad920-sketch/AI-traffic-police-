"""
Quick inspection of detections in sample_traffic.mp4.
"""
import cv2
from ultralytics import YOLO

model = YOLO("yolov8n.pt")
cap = cv2.VideoCapture("sample_traffic.mp4")
total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
fps = cap.get(cv2.CAP_PROP_FPS)
print(f"Total Frames: {total_frames}, FPS: {fps}")

detected_classes = set()
frame_idx = 0
while cap.isOpened() and frame_idx < 150:
    ret, frame = cap.read()
    if not ret:
        break
    frame_idx += 1
    results = model(frame, verbose=False)
    if results and len(results) > 0:
        for box in results[0].boxes:
            cls_name = model.names[int(box.cls[0].item())]
            detected_classes.add(cls_name)

print("Detected classes in first 150 frames:", detected_classes)
cap.release()
