"""
Production Enterprise Configuration Settings.
Loads strictly from environment variables with safe defaults.
Zero hardcoded filesystem paths.
"""
import os
from pathlib import Path
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent

class ServiceConfig(BaseModel):
    # Deployment environment
    ENVIRONMENT: str = Field(default_factory=lambda: os.getenv("ENVIRONMENT", "production"))
    DEBUG: bool = Field(default_factory=lambda: os.getenv("DEBUG", "false").lower() == "true")
    
    # API & Networking
    API_HOST: str = Field(default_factory=lambda: os.getenv("API_HOST", "0.0.0.0"))
    API_PORT: int = Field(default_factory=lambda: int(os.getenv("API_PORT", "8000")))
    API_SECRET_KEY: str = Field(default_factory=lambda: os.getenv("API_SECRET_KEY", "gov_police_secret_key_change_in_prod"))
    
    # Storage - Database & Object Store (S3 / MinIO)
    DATABASE_URL: str = Field(default_factory=lambda: os.getenv("DATABASE_URL", f"sqlite:///{BASE_DIR / 'violations' / 'traffic_police.db'}"))
    MINIO_ENDPOINT: str = Field(default_factory=lambda: os.getenv("MINIO_ENDPOINT", "localhost:9000"))
    MINIO_ACCESS_KEY: str = Field(default_factory=lambda: os.getenv("MINIO_ACCESS_KEY", "minioadmin"))
    MINIO_SECRET_KEY: str = Field(default_factory=lambda: os.getenv("MINIO_SECRET_KEY", "minioadmin"))
    MINIO_BUCKET_NAME: str = Field(default_factory=lambda: os.getenv("MINIO_BUCKET_NAME", "traffic-violations"))
    MINIO_SECURE: bool = Field(default_factory=lambda: os.getenv("MINIO_SECURE", "false").lower() == "true")
    LOCAL_STORAGE_DIR: Path = Field(default_factory=lambda: Path(os.getenv("LOCAL_STORAGE_DIR", str(BASE_DIR / "violations"))))
    
    # Message Bus (Kafka / NATS / Redis / Local InMemory RingBuffer)
    MESSAGE_BUS_TYPE: str = Field(default_factory=lambda: os.getenv("MESSAGE_BUS_TYPE", "in_memory")) # 'kafka', 'nats', 'in_memory'
    KAFKA_BOOTSTRAP_SERVERS: str = Field(default_factory=lambda: os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"))
    NATS_URL: str = Field(default_factory=lambda: os.getenv("NATS_URL", "nats://localhost:4222"))
    
    # Video Ingestion & Sampling Strategy
    DEFAULT_SAMPLING_FPS: float = Field(default_factory=lambda: float(os.getenv("DEFAULT_SAMPLING_FPS", "3.0"))) # 1-5 FPS
    MAX_QUEUE_SIZE: int = Field(default_factory=lambda: int(os.getenv("MAX_QUEUE_SIZE", "150"))) # Drop-oldest queue cap
    MOTION_DETECTION_ENABLED: bool = Field(default_factory=lambda: os.getenv("MOTION_DETECTION_ENABLED", "true").lower() == "true")
    MOTION_THRESHOLD_PERCENT: float = Field(default_factory=lambda: float(os.getenv("MOTION_THRESHOLD_PERCENT", "0.015")))
    
    # YOLO & Tracking Settings (Detection accuracy untouched)
    MODEL_NAME: str = Field(default_factory=lambda: os.getenv("MODEL_NAME", "yolov8n.pt"))
    CONFIDENCE_THRESHOLD: float = Field(default_factory=lambda: float(os.getenv("CONFIDENCE_THRESHOLD", "0.35")))
    INFERENCE_IMGSZ: int = Field(default_factory=lambda: int(os.getenv("INFERENCE_IMGSZ", "480")))
    BATCH_SIZE: int = Field(default_factory=lambda: int(os.getenv("BATCH_SIZE", "4")))
    
    # OCR & Human Review Queue
    OCR_CONFIDENCE_THRESHOLD: float = Field(default_factory=lambda: float(os.getenv("OCR_CONFIDENCE_THRESHOLD", "0.75")))
    
    # Violation Deduplication
    DEDUPLICATION_WINDOW_SECONDS: float = Field(default_factory=lambda: float(os.getenv("DEDUPLICATION_WINDOW_SECONDS", "10.0")))
    
    # Metrics & Observability
    PROMETHEUS_PORT: int = Field(default_factory=lambda: int(os.getenv("PROMETHEUS_PORT", "9100")))

settings = ServiceConfig()
