"""
Simple, Secure Unified Authentication System for Traffic Police AI Dashboard.
Provides clean single-login credentials with bcrypt hashing and immutable audit logging.
No complex multi-account switching or lockouts — simple, dependable direct login.
"""
import os
import json
import time
import bcrypt
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional, Tuple
import streamlit as st

from logger import get_logger
from database import db

logger = get_logger("AuthManager")

USERS_FILE = Path(__file__).resolve().parent / "users.json"

def hash_password(plain_password: str) -> str:
    salt = bcrypt.gensalt(rounds=12)
    return bcrypt.hashpw(plain_password.encode('utf-8'), salt).decode('utf-8')

def verify_password(plain_password: str, hashed_password: str) -> bool:
    try:
        return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))
    except Exception as e:
        logger.error(f"Password check exception: {e}")
        return False

class AuthManager:
    def __init__(self):
        self._init_users_file()

    def _init_users_file(self):
        admin_pass = os.getenv("DEFAULT_ADMIN_PASSWORD", "policeadmin123")
        hashed = hash_password(admin_pass)
        initial_data = {
            "admin": {
                "password_hash": hashed,
                "name": "Traffic Police Department",
                "role": "admin"
            }
        }
        try:
            with open(USERS_FILE, "w", encoding="utf-8") as f:
                json.dump(initial_data, f, indent=2)
            logger.info("Initialized unified user login.")
        except Exception as e:
            logger.error(f"Error initializing users: {e}")

    def get_users(self) -> Dict[str, dict]:
        try:
            if USERS_FILE.exists():
                with open(USERS_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load users: {e}")
        return {}

    def authenticate(self, username: str, password: str, client_ip: str = "127.0.0.1") -> Tuple[bool, Optional[dict]]:
        users = self.get_users()
        u = username.strip().lower()

        # If user typed 'admin' or just clicked with credentials
        user = users.get(u) or users.get("admin")
        if not user:
            self._init_users_file()
            users = self.get_users()
            user = users.get("admin")

        if user and (u == "admin" or u == user.get("name", "").lower()) and verify_password(password, user["password_hash"]):
            db.insert_audit_log(user_id=u, action="LOGIN", resource="Dashboard", ip_address=client_ip, status="SUCCESS")
            logger.info(f"Officer logged in: {u}")
            return True, user
        else:
            db.insert_audit_log(user_id=u, action="LOGIN", resource="Dashboard", ip_address=client_ip, status="FAILED")
            logger.warning(f"Failed login attempt for user: {u}")
            return False, None

    def log_evidence_access(self, username: str, evidence_id: str, action: str = "VIEW_EVIDENCE", client_ip: str = "127.0.0.1"):
        db.insert_audit_log(
            user_id=username or "officer",
            action=action,
            resource=evidence_id,
            ip_address=client_ip,
            status="SUCCESS"
        )

auth_manager = AuthManager()

def render_login_form() -> bool:
    """Renders clean, direct login system like before."""
    if "authenticated" not in st.session_state:
        st.session_state["authenticated"] = False
        st.session_state["username"] = None
        st.session_state["user_role"] = None
        st.session_state["user_name"] = None

    if st.session_state["authenticated"]:
        return True

    st.markdown("""
        <div style="max-width: 440px; margin: 60px auto 20px auto; padding: 26px 30px; background-color: #111622; border-radius: 8px; border: 1px solid #1E2638; border-top: 4px solid #2563EB;">
            <div style="display:flex; align-items:center; justify-content:center; gap:8px; margin-bottom: 4px;">
                <span style="font-size:1.6rem;">🚔</span>
                <span style="font-size: 1.25rem; font-weight: 700; color: #F8FAFC;">TRAFFIC POLICE AI</span>
            </div>
            <div style="font-size: 0.8rem; color: #94A3B8; text-align: center;">Official Law Enforcement Command Center</div>
        </div>
    """, unsafe_allow_html=True)

    col1, col2, col3 = st.columns([1, 1.1, 1])
    with col2:
        with st.container(border=True):
            st.markdown("<div style='font-size:0.78rem; font-weight:600; color:#38BDF8; margin-bottom:12px;'>🔒 Login to Access System</div>", unsafe_allow_html=True)
            username = st.text_input("Username", value="admin", key="login_username")
            password = st.text_input("Password", type="password", key="login_password")

            if st.button("Login", type="primary", use_container_width=True):
                if username and password:
                    success, user_data = auth_manager.authenticate(username, password)
                    if success:
                        st.session_state["authenticated"] = True
                        st.session_state["username"] = username
                        st.session_state["user_role"] = user_data.get("role", "admin")
                        st.session_state["user_name"] = user_data.get("name", "Traffic Police")
                        st.success("Login Successful!")
                        time.sleep(0.3)
                        st.rerun()
                    else:
                        st.error("❌ Invalid username or password.")
                else:
                    st.warning("Please enter both username and password.")

            st.caption("Default Login: `admin` / `policeadmin123`")
    return False

def render_logout_sidebar():
    """Renders simple user profile badge and logout button in sidebar."""
    if st.session_state.get("authenticated"):
        st.sidebar.markdown(f"""
            <div style="background-color: #111622; padding: 10px 12px; border-radius: 6px; border: 1px solid #1E2638; border-left: 3px solid #10B981; margin-bottom: 14px;">
                <span style="font-size: 0.72rem; color: #94A3B8;">LOGGED IN:</span><br/>
                <b style="color: #F8FAFC; font-size: 0.88rem;">👤 {st.session_state.get('user_name')}</b><br/>
                <span style="font-size: 0.72rem; color: #38BDF8;">ROLE: {st.session_state.get('user_role', 'Admin').upper()}</span>
            </div>
        """, unsafe_allow_html=True)
        if st.sidebar.button("🚪 Logout", use_container_width=True):
            auth_manager.log_evidence_access(st.session_state.get("username", "admin"), "Dashboard", action="LOGOUT")
            st.session_state["authenticated"] = False
            st.session_state["username"] = None
            st.rerun()
