"""
Prometheus Metrics for Traffic Violation Detection System.
Tracks real-time system performance across thousands of camera feeds:
- Ingested frames & dropped frames
- Camera status gauges (online/offline)
- Inference latency per model pass
- Violations detected by type
- OCR human-review queue depth
"""
from prometheus_client import Counter, Gauge, Histogram, generate_latest, CONTENT_TYPE_LATEST

# Frame ingestion & drop counters
FRAMES_INGESTED = Counter(
    "traffic_frames_ingested_total",
    "Total frames decoded from cameras",
    ["camera_id"]
)

FRAMES_DROPPED = Counter(
    "traffic_frames_dropped_total",
    "Total frames dropped by queue drop-oldest policy under load",
    ["camera_id", "reason"]
)

# Queue depth & memory backpressure
QUEUE_DEPTH = Gauge(
    "traffic_frame_queue_depth",
    "Current number of frames buffered in queue",
    ["worker_id"]
)

# Active camera status
CAMERA_ONLINE = Gauge(
    "traffic_camera_online_status",
    "Camera connectivity status (1 = Online, 0 = Offline)",
    ["camera_id", "zone"]
)

# Inference Latency (YOLO + tracking)
INFERENCE_LATENCY = Histogram(
    "traffic_inference_duration_seconds",
    "Time spent executing YOLOv8 + ByteTrack on frame batch",
    buckets=[0.005, 0.01, 0.02, 0.035, 0.05, 0.075, 0.1, 0.25, 0.5, 1.0]
)

# Violations caught
VIOLATIONS_COUNT = Counter(
    "traffic_violations_total",
    "Total traffic violations detected by category",
    ["violation_type", "camera_id"]
)

# OCR Metrics
OCR_CONFIDENCE = Histogram(
    "traffic_ocr_confidence_score",
    "Confidence score distribution of ALPR plate reads",
    buckets=[0.1, 0.3, 0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1.0]
)

OCR_REVIEW_QUEUE_DEPTH = Gauge(
    "traffic_ocr_review_queue_depth",
    "Number of ambiguous plate reads pending human officer verification"
)
