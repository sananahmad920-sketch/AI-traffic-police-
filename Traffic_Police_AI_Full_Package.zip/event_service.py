"""
FastAPI Microservice: Centralized Violation & Evidence Event Service.
Provides RESTful APIs for:
- Ingesting violations from distributed inference nodes
- Querying certified violations with date partitioning
- Prometheus metrics scraping (/metrics)
- Human review queue for ambiguous license plate reads
- Camera health and telemetry monitoring
"""
import time
from typing import List, Optional
from fastapi import FastAPI, HTTPException, Header, Depends, Query, Response
from pydantic import BaseModel
from prometheus_client import generate_latest, CONTENT_TYPE_LATEST

from service_config import settings
from database import db
from deduplicator import deduplicator
from ocr_service import ocr_service
from metrics import VIOLATIONS_COUNT
from logger import get_logger

logger = get_logger("EventAPI")

app = FastAPI(
    title="Smart Traffic Police AI - Enterprise Event Service",
    description="Centralized REST API for high-scale traffic violation capture, deduplication, and evidence audit trails.",
    version="2.0.0"
)

# Pydantic Schemas
class ViolationEvent(BaseModel):
    violation_id: str
    timestamp: str
    date: str
    time: str
    camera_id: str
    track_id: int
    vehicle_type: str
    plate_number: str
    violation_type: str
    detail: str
    speed_kmh: float
    evidence_image: str
    sha256_hash: str
    storage_uri: Optional[str] = None
    ocr_confidence: Optional[float] = 1.0

class PlateReviewResolution(BaseModel):
    violation_id: str
    corrected_plate: str
    officer_id: str

# API Endpoints
@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "service": "TrafficPolice-EventAPI",
        "timestamp": time.time(),
        "database": db.get_database_stats()
    }

@app.get("/metrics")
def metrics():
    """Prometheus metrics endpoint."""
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)

@app.post("/api/v1/violations", status_code=201)
def record_violation(event: ViolationEvent):
    """
    Ingests confirmed violation from inference worker nodes.
    Validates deduplication, writes to PostgreSQL, and stores audit log.
    """
    if deduplicator.is_duplicate(event.camera_id, event.track_id, event.violation_type):
        return {"status": "ignored", "reason": "duplicate_within_sliding_window"}

    record_dict = event.dict()
    success = db.insert_violation(record_dict)
    if not success:
        raise HTTPException(status_code=500, detail="Database persistence failed")

    VIOLATIONS_COUNT.labels(violation_type=event.violation_type, camera_id=event.camera_id).inc()
    return {"status": "success", "violation_id": event.violation_id, "sha256": event.sha256_hash}

@app.get("/api/v1/violations")
def list_violations(
    limit: int = Query(50, ge=1, le=500),
    camera_id: Optional[str] = None,
    plate: Optional[str] = None,
    violation_type: Optional[str] = None
):
    """Query certified violations."""
    records = db.get_violations(
        limit=limit,
        camera_id=camera_id,
        plate_filter=plate,
        violation_type=violation_type
    )
    return {"count": len(records), "results": records}

@app.get("/api/v1/ocr/pending-reviews")
def get_pending_ocr_reviews():
    """Returns ambiguous ALPR plate reads awaiting human officer review."""
    return {"pending_reviews": ocr_service.get_pending_reviews()}

@app.post("/api/v1/ocr/resolve")
def resolve_ocr_review(resolution: PlateReviewResolution):
    """Allows authorized police officer to confirm or correct license plate."""
    success = ocr_service.resolve_review(
        violation_id=resolution.violation_id,
        corrected_plate=resolution.corrected_plate,
        officer_id=resolution.officer_id
    )
    if not success:
        raise HTTPException(status_code=404, detail="Review item not found")
    return {"status": "resolved", "corrected_plate": resolution.corrected_plate}

@app.get("/api/v1/audits")
def get_audit_trail(limit: int = 100):
    return {"audits": db.get_audit_logs(limit=limit)}
