"""
High-Throughput Batch Inference & Violation Detection Worker.
Consumes frames from bounded queues, executes YOLOv8 + ByteTrack,
runs traffic safety rules (Red Light, Speed, Helmet, Wrong Way, Swerving, Tailgating),
and publishes verified violations to the event service.
"""
import time
import cv2
import threading
from typing import Dict, List, Optional
import numpy as np

from logger import get_logger
from metrics import INFERENCE_LATENCY, VIOLATIONS_COUNT
from frame_queue import BoundedFrameQueue
from detector import get_shared_yolo_model
from processor import TrafficViolationProcessor
from deduplicator import deduplicator
from ocr_service import ocr_service
from storage_service import storage_service
from database import db
from service_config import settings

logger = get_logger("InferenceWorker")

class InferenceWorker:
    def __init__(self, worker_id: str, input_queue: BoundedFrameQueue, event_callback = None):
        self.worker_id = worker_id
        self.input_queue = input_queue
        self.event_callback = event_callback
        self._running = False
        self._thread: Optional[threading.Thread] = None

        # Pre-warmed shared YOLO model
        self.shared_model = get_shared_yolo_model(settings.MODEL_NAME)
        # Processors cache per camera
        self.processors: Dict[str, TrafficViolationProcessor] = {}

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._run_loop, name=f"Inference-{self.worker_id}", daemon=True)
        self._thread.start()
        logger.info(f"Started Inference Worker '{self.worker_id}' with batch size {settings.BATCH_SIZE}")

    def stop(self):
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)

    def _get_processor(self, camera_id: str) -> TrafficViolationProcessor:
        if camera_id not in self.processors:
            self.processors[camera_id] = TrafficViolationProcessor(
                camera_id=camera_id,
                imgsz=settings.INFERENCE_IMGSZ,
                shared_yolo_model=self.shared_model
            )
        return self.processors[camera_id]

    def _run_loop(self):
        while self._running:
            item = self.input_queue.get(timeout=0.5)
            if item is None:
                continue

            camera_id, frame, timestamp = item
            processor = self._get_processor(camera_id)

            t0 = time.time()
            # Downscale for detection size
            fh, fw = frame.shape[:2]
            scale = 640.0 / fw
            frame_resized = cv2.resize(frame, (640, int(fh * scale)))

            annotated_frame, violations = processor.process_frame(
                frame=frame_resized,
                camera_id=camera_id
            )
            duration = time.time() - t0
            INFERENCE_LATENCY.observe(duration)

            for v in violations:
                vtype = v["violation_type"]
                track_id = v.get("track_id", -1)

                # Deduplication check: drop duplicate frames of same violation within 10s
                if deduplicator.is_duplicate(camera_id, track_id, vtype, timestamp):
                    continue

                VIOLATIONS_COUNT.labels(violation_type=vtype, camera_id=camera_id).inc()

                # Compress evidence and store via StorageService (S3/MinIO/Local)
                image_path = v.get("evidence_image")
                if image_path:
                    try:
                        with open(image_path, "rb") as f:
                            img_bytes = f.read()
                        object_name = f"{camera_id}/{v['violation_id']}.jpg"
                        storage_uri, sha256_hash = storage_service.store_evidence(img_bytes, object_name)
                        v["storage_uri"] = storage_uri
                        v["sha256_hash"] = sha256_hash
                    except Exception as e:
                        logger.warning(f"Storage upload error for {v['violation_id']}: {e}")

                # OCR Verification
                vh, vw = frame.shape[:2]
                bbox = v.get("bbox", (0, 0, vw, vh))
                x1, y1, x2, y2 = bbox
                crop = frame[max(0, y1):min(vh, y2), max(0, x1):min(vw, x2)]
                
                plate, conf, needs_review = ocr_service.read_plate(crop, track_id)
                v["plate_number"] = plate
                v["ocr_confidence"] = conf
                
                if needs_review:
                    ocr_service.submit_for_review(v)

                # Route event
                if self.event_callback:
                    self.event_callback(v)

                logger.info(f"[🚨 VIOLATION CONFIRMED] [{camera_id}] {v['violation_id']} | Type: {vtype} | Plate: {plate} (Conf: {conf})")
