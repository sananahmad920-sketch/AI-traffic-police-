"""
Dubai Police Smart Fine, Black Points & SMS Challan Engine.
Maps violation types directly to official Dubai Police / RTA Traffic Tariff:
- Fine amount in AED (and PKR/USD converter)
- Official Black Points deduction
- Impoundment penalty duration (days)
- Automated e-Challan SMS notice generator
"""
from typing import Dict, Tuple

# Official UAE Federal Traffic Law / Dubai Police Tariff Reference
DUBAI_FINE_SCHEDULE: Dict[str, dict] = {
    "RED_LIGHT_JUMP": {
        "fine_aed": 1000,
        "black_points": 12,
        "impound_days": 30,
        "category": "Severe Life-Threatening Violation",
        "article": "Article 15 - Red Light Signal Non-Compliance"
    },
    "OVERSPEED": {
        "fine_aed": 600,
        "black_points": 6,
        "impound_days": 0,
        "category": "Speed Limit Violation (>30 km/h over)",
        "article": "Article 33 - Speed Limit Exceeded"
    },
    "TAILGATING_VIOLATION": {
        "fine_aed": 400,
        "black_points": 4,
        "impound_days": 0,
        "category": "Safe Distance Non-Compliance",
        "article": "Article 52 - Failure to Leave Sufficient Safety Distance"
    },
    "SUDDEN_SWERVING": {
        "fine_aed": 1000,
        "black_points": 4,
        "impound_days": 0,
        "category": "Dangerous Driving / Sudden Swerve",
        "article": "Article 29 - Sudden Lane Deviation"
    },
    "WRONG_WAY": {
        "fine_aed": 600,
        "black_points": 4,
        "impound_days": 7,
        "category": "Reckless Driving",
        "article": "Article 48 - Driving Against Traffic Direction"
    },
    "NO_HELMET_VIOLATION": {
        "fine_aed": 500,
        "black_points": 4,
        "impound_days": 0,
        "category": "Safety Equipment Non-Compliance",
        "article": "Article 71 - Rider Helmet Non-Compliance"
    },
    "TRIPLE_RIDING_VIOLATION": {
        "fine_aed": 500,
        "black_points": 4,
        "impound_days": 0,
        "category": "Passenger Limit Exceeded",
        "article": "Article 72 - Unauthorized Pillions"
    }
}

DEFAULT_FINE = {
    "fine_aed": 400,
    "black_points": 2,
    "impound_days": 0,
    "category": "General Infraction",
    "article": "Traffic Safety Code"
}

def get_dubai_penalty(violation_type: str) -> dict:
    """Returns official Dubai Police penalty details."""
    return DUBAI_FINE_SCHEDULE.get(violation_type, DEFAULT_FINE)

def generate_sms_notification(plate_number: str, violation_type: str, timestamp_str: str, location: str = "Sheikh Zayed Road") -> str:
    """Generates official automated Dubai Police e-Challan SMS notice."""
    pen = get_dubai_penalty(violation_type)
    msg = (
        f"DUBAI POLICE NOTICE: Traffic violation ({violation_type}) recorded for vehicle [{plate_number}] "
        f"at {location} on {timestamp_str}. Fine: AED {pen['fine_aed']} | Black Points: {pen['black_points']}. "
        f"Pay or dispute within 14 days at dubaipolice.gov.ae or smart app."
    )
    return msg
