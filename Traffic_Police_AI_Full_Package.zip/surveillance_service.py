"""
Autonomous Multi-Camera 24/7 Headless Surveillance Service.
Runs continuous traffic violation monitoring from multiple RTSP streams, CCTV files, or webcams.
Each camera feed runs in its own isolated thread with exponential backoff reconnect.
Persists tamper-evident evidence and SHA-256 hashes to PostgreSQL/Database.
"""
import argparse
import sys
import time
import signal
from pathlib import Path
import cv2

CURRENT_DIR = Path(__file__).resolve().parent
if str(CURRENT_DIR) not in sys.path:
    sys.path.append(str(CURRENT_DIR))

import config
from logger import get_logger
from database import db
from camera_manager import camera_manager
from processor import TrafficViolationProcessor

logger = get_logger("SurveillanceDaemon")

def run_service():
    parser = argparse.ArgumentParser(description="Smart Traffic Police Autonomous Multi-Camera Surveillance Daemon")
    parser.add_argument("--sources", nargs="+", default=["traffic_cctv.mp4"], help="List of video files, webcam indices, or RTSP URLs (e.g. CAM-01=rtsp://... CAM-02=rtsp://...)")
    parser.add_argument("--speed-limit", type=float, default=45.0, help="Speed limit in km/h")
    parser.add_argument("--stop-line", type=int, default=260, help="Stop line Y coordinate")
    parser.add_argument("--frame-skip", type=int, default=3, help="Process every Nth frame")
    parser.add_argument("--imgsz", type=int, default=384, help="YOLO inference size")
    args = parser.parse_args()

    print("=" * 75)
    print("      SMART TRAFFIC POLICE AI: ENTERPRISE 24/7 MULTI-CAM DAEMON")
    print("=" * 75)
    print(f"[*] Speed Limit: {args.speed_limit} km/h | Stop Line Y: {args.stop_line} px")
    print(f"[*] AI Frame Skip: {args.frame_skip} | Imgsz: {args.imgsz}")
    print(f"[*] Storage Dir: {config.EVIDENCE_DIR}")
    print("=" * 75)

    # Initialize processors per camera
    processors = {}
    
    # Parse camera sources
    for i, s_arg in enumerate(args.sources, start=1):
        if "=" in s_arg:
            cam_id, source = s_arg.split("=", 1)
        else:
            cam_id = f"CAM-{i:02d}"
            source = s_arg

        # Handle local relative files
        if not source.startswith("rtsp://") and not source.isdigit() and not Path(source).is_absolute():
            source = str(CURRENT_DIR / source)

        camera_manager.add_camera(cam_id, source, location_name=f"Junction {cam_id}")
        processors[cam_id] = TrafficViolationProcessor(
            speed_limit_kmh=args.speed_limit,
            stop_line_y=args.stop_line,
            imgsz=args.imgsz,
            frame_skip=args.frame_skip,
            enable_ocr=True,
            camera_id=cam_id
        )
        logger.info(f"Initialized processor for camera {cam_id} ({source})")

    running = True
    def signal_handler(sig, frame):
        nonlocal running
        logger.info("Received shutdown signal. Stopping surveillance daemon cleanly...")
        running = False

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    logger.info("Surveillance loop active across all registered cameras.")

    start_time = time.time()
    last_stat_time = time.time()
    frame_counts = {cid: 0 for cid in processors}

    try:
        while running:
            for cam_id, processor in processors.items():
                worker = camera_manager.get_camera(cam_id)
                if not worker or not worker.is_connected:
                    continue

                is_conn, frame, ts = worker.get_latest_frame()
                if frame is None:
                    continue

                frame_counts[cam_id] += 1
                fh, fw = frame.shape[:2]
                scale = 640 / fw
                frame_resized = cv2.resize(frame, (640, int(fh * scale)))

                annotated, new_viols = processor.process_frame(frame_resized, camera_id=cam_id)
                if new_viols:
                    for v in new_viols:
                        print(f"  [🚨 VIOLATION LOGGED] [{cam_id}] {v['timestamp']} | ID: {v['track_id']} | Type: {v['violation_type']} | Plate: {v['plate_number']} | Hash: {v.get('sha256_hash', '')[:16]}...")

            time.sleep(0.01)

            # Periodic status log
            now = time.time()
            if now - last_stat_time >= 15.0:
                elapsed = now - start_time
                total_f = sum(frame_counts.values())
                avg_fps = total_f / max(elapsed, 0.1)
                logger.info(f"[TELEMETRY] Uptime: {int(elapsed)}s | Aggregated FPS: {avg_fps:.1f} | Active Cameras: {len(processors)}")
                last_stat_time = now

    finally:
        camera_manager.stop_all()
        logger.info("All camera workers stopped. Database and evidence preserved.")

if __name__ == "__main__":
    run_service()
