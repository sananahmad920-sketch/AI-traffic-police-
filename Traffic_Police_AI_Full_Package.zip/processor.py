"""
Optimized Traffic Violation Pipeline Processor.
Includes camera_id tagging, frame skipping, async OCR, FPS calculation, and fast CPU rendering.
Core YOLO detection logic and weights remain untouched.
"""
import time
import cv2
import numpy as np
from typing import Dict, List, Optional, Tuple

import config
from detector import TrafficDetector
from rules.red_light import RedLightRule
from rules.speed import SpeedViolationRule
from rules.helmet import HelmetRule
from rules.wrong_way import WrongWayRule
from rules.tailgating import TailgatingRule
from rules.lane_discipline import LaneDisciplineRule
from anpr import LicensePlateReader
from evidence import EvidenceLogger

class TrafficViolationProcessor:
    def __init__(
        self,
        speed_limit_kmh: float = config.DEFAULT_SPEED_LIMIT_KMH,
        stop_line_y: int = config.DEFAULT_STOP_LINE_Y,
        speed_line1_y: int = config.DEFAULT_SPEED_LINE_1_Y,
        speed_line2_y: int = config.DEFAULT_SPEED_LINE_2_Y,
        signal_cycle_sec: float = 8.0,
        enable_ocr: bool = True,
        imgsz: int = 480,
        frame_skip: int = 2,
        camera_id: str = "CAM-01",
        shared_yolo_model = None
    ):
        self.camera_id = camera_id
        self.detector = TrafficDetector(imgsz=imgsz, shared_model=shared_yolo_model)
        self.red_light_rule = RedLightRule(stop_line_y=stop_line_y)
        self.speed_rule = SpeedViolationRule(
            line1_y=speed_line1_y,
            line2_y=speed_line2_y,
            speed_limit_kmh=speed_limit_kmh
        )
        self.helmet_rule = HelmetRule()
        self.wrong_way_rule = WrongWayRule(allowed_direction="down")
        self.tailgating_rule = TailgatingRule(min_safe_gap_meters=8.0)
        self.lane_discipline_rule = LaneDisciplineRule(max_lateral_drift_px=85.0)
        self.anpr = LicensePlateReader(use_ocr=enable_ocr)
        self.evidence_logger = EvidenceLogger(config.EVIDENCE_DIR)

        # Performance settings
        self.frame_skip = frame_skip
        self.frame_counter = 0
        self.cached_detections = {"vehicles": [], "persons": [], "traffic_lights": []}

        # Real-time FPS monitoring
        self.prev_time = time.time()
        self.current_fps = 0.0

        # Signal state
        self.signal_state = config.SIGNAL_GREEN
        self.signal_cycle_sec = signal_cycle_sec
        self.last_signal_switch = time.time()
        self.manual_signal_override: Optional[str] = None

        # Violator memory
        self.active_violator_ids: Dict[int, str] = {}
        self.total_vehicles_counted = set()
        self.total_violations_count = 0

    def set_signal_state(self, state: Optional[str]):
        self.manual_signal_override = state

    def set_camera_id(self, camera_id: str):
        self.camera_id = camera_id

    def update_settings(self, speed_limit: float = None, stop_line_y: int = None, frame_skip: int = None, imgsz: int = None, camera_id: str = None):
        if speed_limit is not None:
            self.speed_rule.update_config(speed_limit_kmh=speed_limit)
        if stop_line_y is not None:
            self.red_light_rule.update_stop_line(stop_line_y)
        if frame_skip is not None:
            self.frame_skip = max(1, frame_skip)
        if imgsz is not None:
            self.detector.set_imgsz(imgsz)
        if camera_id is not None:
            self.camera_id = camera_id

    def _update_signal(self):
        if self.manual_signal_override is not None:
            self.signal_state = self.manual_signal_override
            return

        now = time.time()
        if now - self.last_signal_switch >= self.signal_cycle_sec:
            self.signal_state = config.SIGNAL_RED if self.signal_state == config.SIGNAL_GREEN else config.SIGNAL_GREEN
            self.last_signal_switch = now

    def process_frame(
        self,
        frame: np.ndarray,
        enable_red_light: bool = True,
        enable_speed: bool = True,
        enable_helmet: bool = True,
        enable_wrong_way: bool = True,
        camera_id: Optional[str] = None
    ) -> Tuple[np.ndarray, List[dict]]:
        """
        Processes frame with sub-sampled AI inference for real-time CPU speeds.
        Tags each violation with the source camera_id.
        """
        cam_id = camera_id or self.camera_id

        # Calculate instant FPS
        now = time.time()
        dt = now - self.prev_time
        if dt > 0:
            instant_fps = 1.0 / dt
            self.current_fps = 0.85 * self.current_fps + 0.15 * instant_fps
        self.prev_time = now

        self._update_signal()
        self.frame_counter += 1
        h, w = frame.shape[:2]
        hud_frame = frame.copy()

        # Run AI detection only every N frames to keep CPU fast
        should_run_ai = (self.frame_counter % self.frame_skip == 0)

        if should_run_ai:
            self.cached_detections = self.detector.process_frame(frame)

        vehicles = self.cached_detections["vehicles"]
        persons = self.cached_detections["persons"]

        new_violations = []
        is_red = (self.signal_state == config.SIGNAL_RED)

        for v in vehicles:
            track_id = v["track_id"]
            if track_id != -1:
                self.total_vehicles_counted.add(track_id)
            bbox = v["bbox"]
            vtype = v["class_name"]
            x1, y1, x2, y2 = bbox

            # Safe crop
            crop = frame[max(0, y1):min(h, y2), max(0, x1):min(w, x2)]

            # Check Speed
            current_speed = 0.0
            if enable_speed and track_id != -1:
                spd_violation, current_speed = self.speed_rule.check_violation(track_id, bbox, current_time=now)
                if spd_violation and should_run_ai:
                    plate = self.anpr.read_plate(crop, track_id)
                    rec = self.evidence_logger.log_violation(
                        frame=frame,
                        track_id=track_id,
                        vehicle_type=vtype,
                        plate_number=plate,
                        violation_type="OVERSPEED",
                        detail=spd_violation["detail"],
                        bbox=bbox,
                        speed_kmh=spd_violation.get("speed_kmh", current_speed),
                        camera_id=cam_id
                    )
                    self.active_violator_ids[track_id] = "OVERSPEED"
                    new_violations.append(rec)
                    self.total_violations_count += 1

            # Check Red Light
            if enable_red_light and track_id != -1 and should_run_ai:
                rl_violation = self.red_light_rule.check_violation(track_id, bbox, is_red)
                if rl_violation:
                    plate = self.anpr.read_plate(crop, track_id)
                    rec = self.evidence_logger.log_violation(
                        frame=frame,
                        track_id=track_id,
                        vehicle_type=vtype,
                        plate_number=plate,
                        violation_type="RED_LIGHT_JUMP",
                        detail=rl_violation["detail"],
                        bbox=bbox,
                        speed_kmh=current_speed,
                        camera_id=cam_id
                    )
                    self.active_violator_ids[track_id] = "RED_LIGHT"
                    new_violations.append(rec)
                    self.total_violations_count += 1

            # Check Helmet & Passenger (Motorcycles)
            if enable_helmet and vtype == "motorcycle" and track_id != -1 and should_run_ai:
                hl_violations = self.helmet_rule.check_two_wheeler_violations(
                    bike_track_id=track_id,
                    bike_bbox=bbox,
                    detected_persons=persons,
                    frame=frame
                )
                for hv in hl_violations:
                    plate = self.anpr.read_plate(crop, track_id)
                    rec = self.evidence_logger.log_violation(
                        frame=frame,
                        track_id=track_id,
                        vehicle_type=vtype,
                        plate_number=plate,
                        violation_type=hv["rule"],
                        detail=hv["detail"],
                        bbox=bbox,
                        speed_kmh=current_speed,
                        camera_id=cam_id
                    )
                    self.active_violator_ids[track_id] = hv["rule"]
                    new_violations.append(rec)
                    self.total_violations_count += 1

            # Check Wrong-Way Driving
            if enable_wrong_way and track_id != -1 and should_run_ai:
                ww_violation = self.wrong_way_rule.check_violation(track_id, bbox)
                if ww_violation:
                    plate = self.anpr.read_plate(crop, track_id)
                    rec = self.evidence_logger.log_violation(
                        frame=frame,
                        track_id=track_id,
                        vehicle_type=vtype,
                        plate_number=plate,
                        violation_type="WRONG_WAY",
                        detail=ww_violation["detail"],
                        bbox=bbox,
                        speed_kmh=current_speed,
                        camera_id=cam_id
                    )
                    self.active_violator_ids[track_id] = "WRONG_WAY"
                    new_violations.append(rec)
                    self.total_violations_count += 1

            # Dubai Feature: Check Sudden Swerving / Lane Discipline
            if track_id != -1 and should_run_ai:
                sw_violation = self.lane_discipline_rule.check_swerve(track_id, bbox)
                if sw_violation:
                    plate = self.anpr.read_plate(crop, track_id)
                    rec = self.evidence_logger.log_violation(
                        frame=frame,
                        track_id=track_id,
                        vehicle_type=vtype,
                        plate_number=plate,
                        violation_type="SUDDEN_SWERVING",
                        detail=sw_violation["detail"],
                        bbox=bbox,
                        speed_kmh=current_speed,
                        camera_id=cam_id
                    )
                    self.active_violator_ids[track_id] = "SWERVING"
                    new_violations.append(rec)
                    self.total_violations_count += 1

            self._draw_vehicle_bbox(hud_frame, bbox, track_id, vtype, current_speed)

        # Dubai Feature: Check Tailgating / Safe Distance
        if should_run_ai and len(vehicles) >= 2:
            tg_violations = self.tailgating_rule.check_tailgating(vehicles)
            for tg in tg_violations:
                t_id = tg["tail_id"]
                tail_v = next((v for v in vehicles if v.get("track_id") == t_id), None)
                if tail_v:
                    t_bbox = tail_v["bbox"]
                    t_crop = frame[max(0, t_bbox[1]):min(h, t_bbox[3]), max(0, t_bbox[0]):min(w, t_bbox[2])]
                    plate = self.anpr.read_plate(t_crop, t_id)
                    rec = self.evidence_logger.log_violation(
                        frame=frame,
                        track_id=t_id,
                        vehicle_type=tail_v.get("class_name", "car"),
                        plate_number=plate,
                        violation_type="TAILGATING_VIOLATION",
                        detail=tg["detail"],
                        bbox=t_bbox,
                        speed_kmh=0.0,
                        camera_id=cam_id
                    )
                    self.active_violator_ids[t_id] = "TAILGATING"
                    new_violations.append(rec)
                    self.total_violations_count += 1

        self._draw_hud_overlays(hud_frame, w, h, cam_id)

        return hud_frame, new_violations

    def _draw_vehicle_bbox(self, frame: np.ndarray, bbox: tuple, track_id: int, vtype: str, speed_kmh: float):
        x1, y1, x2, y2 = bbox
        is_violator = track_id in self.active_violator_ids

        if is_violator:
            color = (0, 0, 255)
            thickness = 2
            label = f"! VIOLATION ! ID:{track_id} ({vtype})"
        else:
            color = (0, 255, 0)
            thickness = 2
            speed_str = f" | {int(speed_kmh)} km/h" if speed_kmh > 0 else ""
            label = f"ID:{track_id} {vtype}{speed_str}"

        cv2.rectangle(frame, (x1, y1), (x2, y2), color, thickness)
        (lbl_w, lbl_h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.45, 1)
        cv2.rectangle(frame, (x1, max(0, y1 - 20)), (x1 + lbl_w + 6, y1), color, -1)
        cv2.putText(frame, label, (x1 + 3, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                    (0, 0, 0) if not is_violator else (255, 255, 255), 1, cv2.LINE_AA)

    def _draw_hud_overlays(self, frame: np.ndarray, width: int, height: int, camera_id: str):
        stop_y = self.red_light_rule.stop_line_y
        line1_y = self.speed_rule.line1_y
        line2_y = self.speed_rule.line2_y

        # Draw Stop Line
        stop_color = (0, 0, 255) if self.signal_state == config.SIGNAL_RED else (0, 220, 0)
        cv2.line(frame, (0, stop_y), (width, stop_y), stop_color, 2)
        cv2.putText(frame, f"STOP LINE (Signal: {self.signal_state})", (15, stop_y - 8),
                    cv2.FONT_HERSHEY_DUPLEX, 0.55, stop_color, 1)

        # Draw Speed Trap Lines
        cv2.line(frame, (0, line1_y), (width, line1_y), (255, 200, 0), 1)
        cv2.putText(frame, "SPEED TRAP: LINE 1", (width - 190, line1_y - 6),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 200, 0), 1)

        cv2.line(frame, (0, line2_y), (width, line2_y), (255, 200, 0), 1)
        cv2.putText(frame, "SPEED TRAP: LINE 2", (width - 190, line2_y - 6),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 200, 0), 1)

        # Top Traffic Police Status Banner
        overlay = frame.copy()
        cv2.rectangle(overlay, (0, 0), (width, 42), (20, 20, 20), -1)
        cv2.addWeighted(overlay, 0.8, frame, 0.2, 0, frame)

        # Signal Light Indicator
        sig_color = (0, 0, 255) if self.signal_state == config.SIGNAL_RED else (0, 255, 0)
        cv2.circle(frame, (25, 21), 11, sig_color, -1)
        cv2.circle(frame, (25, 21), 12, (255, 255, 255), 1)
        cv2.putText(frame, f"SIGNAL: {self.signal_state}", (45, 26),
                    cv2.FONT_HERSHEY_DUPLEX, 0.55, (255, 255, 255), 1)

        # Camera ID & Live FPS Counter
        fps_color = (0, 255, 0) if self.current_fps >= 20 else ((0, 255, 255) if self.current_fps >= 12 else (0, 100, 255))
        cv2.putText(frame, f"[{camera_id}] FPS: {self.current_fps:.1f}", (240, 26),
                    cv2.FONT_HERSHEY_DUPLEX, 0.55, fps_color, 2)

        # Stats on right
        stats_text = f"Tracked: {len(self.total_vehicles_counted)} | Violations: {self.total_violations_count}"
        cv2.putText(frame, stats_text, (width - 280, 26),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
