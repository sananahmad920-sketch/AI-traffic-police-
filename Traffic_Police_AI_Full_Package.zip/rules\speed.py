"""
Hardened Speed Violation Detection Rule.
Includes bounded memory cache, outlier filtering, and monotonic timing.
"""
import time
from typing import Dict, Tuple, Optional

class SpeedViolationRule:
    def __init__(
        self,
        line1_y: int = 180,
        line2_y: int = 340,
        distance_meters: float = 20.0,
        speed_limit_kmh: float = 45.0,
        max_cached_ids: int = 1000
    ):
        self.line1_y = line1_y
        self.line2_y = line2_y
        self.distance_meters = distance_meters
        self.speed_limit_kmh = speed_limit_kmh
        self.max_cached_ids = max_cached_ids

        self.entry_times: Dict[int, float] = {}
        self.vehicle_speeds: Dict[int, float] = {}
        self.history: Dict[int, Tuple[float, float, float]] = {}
        self.penalized_ids = set()

    def update_config(self, speed_limit_kmh: float = None, line1_y: int = None, line2_y: int = None):
        if speed_limit_kmh is not None:
            self.speed_limit_kmh = speed_limit_kmh
        if line1_y is not None:
            self.line1_y = line1_y
        if line2_y is not None:
            self.line2_y = line2_y

    def _prune_cache_if_needed(self):
        if len(self.history) > self.max_cached_ids:
            old_keys = list(self.history.keys())[:int(self.max_cached_ids * 0.3)]
            for k in old_keys:
                self.history.pop(k, None)
                self.entry_times.pop(k, None)
                self.vehicle_speeds.pop(k, None)
                self.penalized_ids.discard(k)

    def check_violation(
        self,
        track_id: int,
        bbox: Tuple[int, int, int, int],
        current_time: float = None
    ) -> Tuple[Optional[dict], float]:
        """
        Calculates smoothed vehicle speed and checks for over-speeding.
        """
        if current_time is None:
            current_time = time.perf_counter()

        self._prune_cache_if_needed()

        x1, y1, x2, y2 = bbox
        cy = (y1 + y2) / 2.0
        calculated_speed = self.vehicle_speeds.get(track_id, 0.0)

        # Line 1 crossing: record entry timestamp
        if cy >= self.line1_y and track_id not in self.entry_times and cy < self.line2_y:
            self.entry_times[track_id] = current_time

        # Line 2 crossing: compute exact time-distance speed
        if cy >= self.line2_y and track_id in self.entry_times:
            elapsed = current_time - self.entry_times[track_id]
            if elapsed > 0.05:
                speed_mps = self.distance_meters / elapsed
                exact_speed = round(speed_mps * 3.6, 1)
                # Filter noise
                if 10.0 <= exact_speed <= 180.0:
                    calculated_speed = exact_speed
                    self.vehicle_speeds[track_id] = calculated_speed
                del self.entry_times[track_id]

        # Instantaneous motion estimation between lines
        if track_id in self.history:
            prev_y, prev_t, prev_spd = self.history[track_id]
            dt = current_time - prev_t
            if 0.03 < dt < 1.0:
                dy = abs(cy - prev_y)
                px_per_m = abs(self.line2_y - self.line1_y) / max(self.distance_meters, 1.0)
                inst_speed = (dy / max(px_per_m, 1.0)) / dt * 3.6
                if 5.0 <= inst_speed <= 160.0:
                    calculated_speed = round(0.75 * calculated_speed + 0.25 * inst_speed, 1) if calculated_speed > 0 else round(inst_speed, 1)
                    self.vehicle_speeds[track_id] = calculated_speed

        self.history[track_id] = (cy, current_time, calculated_speed)

        # Violation check
        if calculated_speed > self.speed_limit_kmh and track_id not in self.penalized_ids:
            self.penalized_ids.add(track_id)
            return {
                "rule": "OVERSPEED_VIOLATION",
                "detail": f"Speed {calculated_speed} km/h exceeded limit of {self.speed_limit_kmh} km/h",
                "track_id": track_id,
                "bbox": bbox,
                "speed_kmh": calculated_speed
            }, calculated_speed

        return None, calculated_speed
