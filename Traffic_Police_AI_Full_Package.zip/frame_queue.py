"""
High-Performance Drop-Oldest Bounded Frame Queue & Motion Filter.
Guarantees memory usage never grows unbounded regardless of stream count or traffic spikes.
Drops oldest frames when consumers experience backpressure.
Features motion-triggered filtering so static empty road frames are discarded prior to YOLO inference.
"""
import time
import queue
import cv2
import numpy as np
from typing import Optional, Tuple
from metrics import FRAMES_DROPPED, QUEUE_DEPTH

class MotionDetector:
    def __init__(self, threshold_percent: float = 0.015):
        self.threshold_percent = threshold_percent
        self.prev_gray = None

    def has_motion(self, frame: np.ndarray) -> bool:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (21, 21), 0)

        if self.prev_gray is None:
            self.prev_gray = gray
            return True

        frame_diff = cv2.absdiff(self.prev_gray, gray)
        thresh = cv2.threshold(frame_diff, 25, 255, cv2.THRESH_BINARY)[1]
        motion_pixels = cv2.countNonZero(thresh)
        total_pixels = frame.shape[0] * frame.shape[1]
        motion_ratio = motion_pixels / float(total_pixels)

        self.prev_gray = gray
        return motion_ratio >= self.threshold_percent

class BoundedFrameQueue:
    """
    Thread-safe bounded ring buffer with explicit Drop-Oldest policy.
    Memory consumption is strictly capped at maxsize * sizeof(frame).
    """
    def __init__(self, maxsize: int = 150, worker_id: str = "worker-0"):
        self.maxsize = maxsize
        self.worker_id = worker_id
        self._queue = queue.Queue(maxsize=maxsize)
        self.motion_detector = MotionDetector()

    def put(self, item: Tuple[str, np.ndarray, float], check_motion: bool = True) -> bool:
        """
        Pushes (camera_id, frame, timestamp).
        If queue is full, drops oldest frame to ensure zero memory bloat.
        """
        camera_id, frame, ts = item

        if check_motion and not self.motion_detector.has_motion(frame):
            FRAMES_DROPPED.labels(camera_id=camera_id, reason="no_motion").inc()
            return False

        if self._queue.full():
            try:
                # Evict oldest frame
                dropped = self._queue.get_nowait()
                FRAMES_DROPPED.labels(camera_id=dropped[0], reason="queue_backpressure").inc()
            except queue.Empty:
                pass

        try:
            self._queue.put_nowait(item)
            QUEUE_DEPTH.labels(worker_id=self.worker_id).set(self._queue.qsize())
            return True
        except queue.Full:
            return False

    def get(self, timeout: float = 0.5) -> Optional[Tuple[str, np.ndarray, float]]:
        try:
            item = self._queue.get(timeout=timeout)
            QUEUE_DEPTH.labels(worker_id=self.worker_id).set(self._queue.qsize())
            return item
        except queue.Empty:
            return None

    def qsize(self) -> int:
        return self._queue.qsize()
