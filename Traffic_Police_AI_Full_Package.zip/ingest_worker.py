"""
Autonomous Camera Ingest & Hardware Video Decoding Worker.
Decodes RTSP / CCTV streams in parallel, samples at configurable FPS (1-5 FPS),
and routes frames into bounded inference queues.
"""
import time
import threading
from typing import Dict, List, Optional
import cv2
import numpy as np

from logger import get_logger
from metrics import FRAMES_INGESTED, CAMERA_ONLINE
from frame_queue import BoundedFrameQueue
from service_config import settings

logger = get_logger("IngestWorker")

class CameraStreamIngestWorker:
    def __init__(self, camera_id: str, rtsp_url: str, output_queue: BoundedFrameQueue, target_fps: float = 3.0, zone: str = "Zone-1"):
        self.camera_id = camera_id
        self.rtsp_url = rtsp_url
        self.output_queue = output_queue
        self.target_fps = target_fps
        self.zone = zone
        self._running = False
        self._thread: Optional[threading.Thread] = None

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._run, name=f"Ingest-{self.camera_id}", daemon=True)
        self._thread.start()
        logger.info(f"Started ingestion worker for {self.camera_id} @ {self.target_fps} FPS")

    def stop(self):
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
        CAMERA_ONLINE.labels(camera_id=self.camera_id, zone=self.zone).set(0)

    def _run(self):
        reconnect_delay = 2.0
        frame_interval = 1.0 / max(0.5, self.target_fps)
        last_sampled_time = 0.0

        while self._running:
            CAMERA_ONLINE.labels(camera_id=self.camera_id, zone=self.zone).set(0)
            cap = None
            try:
                # Handle numeric vs RTSP string
                src = int(self.rtsp_url) if str(self.rtsp_url).isdigit() else str(self.rtsp_url)
                cap = cv2.VideoCapture(src)
                
                # Low-latency RTSP flags
                if isinstance(src, str) and src.startswith("rtsp://"):
                    cap.set(cv2.CAP_PROP_BUFFERSIZE, 2)

                if not cap.isOpened():
                    raise ConnectionError(f"Cannot open stream: {self.rtsp_url}")

                CAMERA_ONLINE.labels(camera_id=self.camera_id, zone=self.zone).set(1)
                reconnect_delay = 2.0
                logger.info(f"Stream established: {self.camera_id}")

                while self._running:
                    ret, frame = cap.read()
                    if not ret:
                        # If local video file, loop continuously
                        if isinstance(src, str) and not src.startswith("rtsp://") and not str(src).isdigit():
                            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                            continue
                        raise ConnectionResetError(f"Stream disconnected: {self.camera_id}")

                    now = time.time()
                    if now - last_sampled_time >= frame_interval:
                        last_sampled_time = now
                        FRAMES_INGESTED.labels(camera_id=self.camera_id).inc()
                        self.output_queue.put((self.camera_id, frame, now), check_motion=settings.MOTION_DETECTION_ENABLED)

                    time.sleep(0.005)

            except Exception as e:
                CAMERA_ONLINE.labels(camera_id=self.camera_id, zone=self.zone).set(0)
                logger.warning(f"Stream error for {self.camera_id}: {e}. Retrying in {reconnect_delay}s...")
                time.sleep(reconnect_delay)
                reconnect_delay = min(reconnect_delay * 2.0, 60.0)
            finally:
                if cap is not None:
                    cap.release()
