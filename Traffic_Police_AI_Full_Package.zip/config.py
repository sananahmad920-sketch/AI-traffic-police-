"""
Configuration settings for the Smart Traffic Police Violation Detection System.
"""
from pathlib import Path

# Base Paths
BASE_DIR = Path(__file__).resolve().parent
EVIDENCE_DIR = BASE_DIR / "violations"
EVIDENCE_DIR.mkdir(parents=True, exist_ok=True)
DATABASE_FILE = EVIDENCE_DIR / "violations.csv"

# YOLO Model Configuration
MODEL_NAME = "yolov8n.pt"  # Nano model: fast, real-time inference on CPU/GPU
CONFIDENCE_THRESHOLD = 0.35

# Target Detection Classes (COCO Dataset IDs)
# 0: person, 2: car, 3: motorcycle, 5: bus, 7: truck, 9: traffic light
VEHICLE_CLASSES = {
    2: "car",
    3: "motorcycle",
    5: "bus",
    7: "truck"
}

# Traffic Violation Thresholds & Settings
DEFAULT_SPEED_LIMIT_KMH = 60.0  # Speed limit in km/h
PIXELS_PER_METER = 8.5          # Default calibration for typical 720p/1080p road cameras

# Stop Line Configuration (Y coordinates or line segments [(x1, y1), (x2, y2)])
DEFAULT_STOP_LINE_Y = 260       # Y-level for red light stop-line
DEFAULT_SPEED_LINE_1_Y = 180    # Upper line for speed trap
DEFAULT_SPEED_LINE_2_Y = 340    # Lower line for speed trap
DISTANCE_METERS_SPEED_ZONE = 20.0  # Real-world distance between Line 1 and Line 2

# Traffic Signal States
SIGNAL_RED = "RED"
SIGNAL_GREEN = "GREEN"
SIGNAL_YELLOW = "YELLOW"
