@echo off
title Smart Traffic Police AI Dashboard
cd /d "%~dp0"
echo ========================================================
echo   SMART TRAFFIC POLICE AI: CAMERA VIOLATION DETECTOR
echo ========================================================
echo Starting Streamlit Dashboard...
".venv\Scripts\python.exe" -m streamlit run app.py --server.port 8501 --server.headless false
pause
