"""
Hardened Helmet & Motorcycle Passenger Violation Rule.
Bounds-checked crops and memory bounded penalty sets.
"""
from typing import Dict, List, Tuple, Optional
import numpy as np

class HelmetRule:
    def __init__(self, max_cached_ids: int = 1000):
        self.max_cached_ids = max_cached_ids
        self.penalized_ids = set()

    def _prune_cache_if_needed(self):
        if len(self.penalized_ids) > self.max_cached_ids:
            # Drop half of old IDs
            self.penalized_ids = set(list(self.penalized_ids)[len(self.penalized_ids)//2:])

    def check_two_wheeler_violations(
        self,
        bike_track_id: int,
        bike_bbox: Tuple[int, int, int, int],
        detected_persons: List[Tuple[int, Tuple[int, int, int, int]]],
        frame: Optional[np.ndarray] = None
    ) -> List[dict]:
        self._prune_cache_if_needed()
        violations = []
        bx1, by1, bx2, by2 = bike_bbox
        bike_width = bx2 - bx1
        bike_height = by2 - by1

        riders = []
        for pid, pbox in detected_persons:
            px1, py1, px2, py2 = pbox
            pcx = (px1 + px2) / 2.0
            pcy = (py1 + py2) / 2.0

            if (bx1 - 0.25 * bike_width <= pcx <= bx2 + 0.25 * bike_width) and \
               (by1 - 0.6 * bike_height <= pcy <= by2):
                riders.append((pid, pbox))

        vkey_triple = f"triple_{bike_track_id}"
        vkey_helmet = f"helmet_{bike_track_id}"

        # 1. Triple Riding Check
        if len(riders) >= 3 and vkey_triple not in self.penalized_ids:
            self.penalized_ids.add(vkey_triple)
            violations.append({
                "rule": "TRIPLE_RIDING_VIOLATION",
                "detail": f"{len(riders)} riders detected on motorcycle (Track ID {bike_track_id})",
                "track_id": bike_track_id,
                "bbox": bike_bbox
            })

        # 2. Helmet Check on detected riders
        if frame is not None and len(riders) > 0 and vkey_helmet not in self.penalized_ids:
            fh, fw = frame.shape[:2]
            for _, rbox in riders:
                rx1, ry1, rx2, ry2 = [int(v) for v in rbox]
                head_h = max(int((ry2 - ry1) * 0.25), 12)
                
                # Bounds clamping
                cy1 = max(0, min(fh - 1, ry1))
                cy2 = max(cy1 + 1, min(fh, ry1 + head_h))
                cx1 = max(0, min(fw - 1, rx1))
                cx2 = max(cx1 + 1, min(fw, rx2))

                head_crop = frame[cy1:cy2, cx1:cx2]
                if head_crop.size > 20:
                    gray_head = np.mean(head_crop, axis=2) if len(head_crop.shape) == 3 else head_crop
                    std_dev = float(np.std(gray_head))
                    mean_val = float(np.mean(gray_head))

                    if std_dev > 48.0 and mean_val < 65.0:
                        self.penalized_ids.add(vkey_helmet)
                        violations.append({
                            "rule": "NO_HELMET_VIOLATION",
                            "detail": f"Rider without helmet detected on motorcycle (Track ID {bike_track_id})",
                            "track_id": bike_track_id,
                            "bbox": bike_bbox
                        })
                        break

        return violations
