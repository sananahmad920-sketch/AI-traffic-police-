"""
Optimized Automatic Number Plate Recognition (ANPR / ALPR) Module.
Runs asynchronously in background worker threads so CPU video stream never stutters.
"""
import re
import cv2
import numpy as np
import threading
from typing import Tuple, Optional, Callable

class LicensePlateReader:
    def __init__(self, use_ocr: bool = True):
        self.use_ocr = use_ocr
        self.reader = None
        self._init_lock = threading.Lock()
        self._reader_initialized = False

    def _ensure_reader(self):
        """Lazy load OCR reader only when needed."""
        if not self._reader_initialized and self.use_ocr:
            with self._init_lock:
                if not self._reader_initialized:
                    try:
                        import easyocr
                        self.reader = easyocr.Reader(['en'], gpu=False, verbose=False)
                    except Exception as e:
                        print(f"[ANPR Warning] Could not initialize EasyOCR: {e}")
                        self.reader = None
                    self._reader_initialized = True

    def extract_plate_region(self, vehicle_crop: np.ndarray) -> Tuple[np.ndarray, Optional[Tuple[int, int, int, int]]]:
        """Locates license plate candidate region."""
        vh, vw = vehicle_crop.shape[:2]
        fallback_w = int(vw * 0.65)
        fallback_h = int(vh * 0.3)
        fallback_x = int((vw - fallback_w) / 2)
        fallback_y = int(vh * 0.6)
        plate_crop = vehicle_crop[fallback_y:fallback_y+fallback_h, fallback_x:fallback_x+fallback_w]
        return plate_crop, (fallback_x, fallback_y, fallback_w, fallback_h)

    def read_plate_async(self, vehicle_crop: np.ndarray, track_id: int, on_complete: Optional[Callable[[str], None]] = None) -> str:
        """
        Immediately returns a fast deterministic plate ID, and launches
        background OCR to refine the plate number without blocking video playback.
        """
        if vehicle_crop is None or vehicle_crop.size == 0:
            return f"POL-TRK{track_id:02d}"

        # Fast deterministic ID based on visual hash
        h_hash = abs(hash(vehicle_crop.tobytes()[:500])) % 9000 + 1000
        fast_plate = f"POL-{track_id:02d}-{h_hash}"

        if not self.use_ocr:
            return fast_plate

        # Run OCR in background daemon thread
        def _ocr_worker():
            try:
                self._ensure_reader()
                if self.reader is not None:
                    plate_crop, _ = self.extract_plate_region(vehicle_crop)
                    if plate_crop.shape[0] >= 15 and plate_crop.shape[1] >= 30:
                        gray = cv2.cvtColor(plate_crop, cv2.COLOR_BGR2GRAY)
                        results = self.reader.readtext(gray)
                        tokens = []
                        for _, text, conf in results:
                            cleaned = re.sub(r'[^A-Za-z0-9]', '', text).upper()
                            if len(cleaned) >= 3 and conf >= 0.25:
                                tokens.append(cleaned)
                        if tokens:
                            refined_plate = "".join(tokens)
                            if on_complete:
                                on_complete(refined_plate)
            except Exception:
                pass

        threading.Thread(target=_ocr_worker, daemon=True).start()
        return fast_plate

    def read_plate(self, vehicle_crop: np.ndarray, track_id: int) -> str:
        """Synchronous fast wrapper for non-blocking read."""
        return self.read_plate_async(vehicle_crop, track_id)
