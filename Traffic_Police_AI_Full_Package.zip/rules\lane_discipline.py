"""
Dubai Police Smart Traffic Rule: Sudden Swerving & Illegal Lane Discipline.
Dubai Police cameras actively issue AED 1,000 fines + 4 black points for sudden
lane deviation and non-compliance with lane markings.
"""
from typing import Dict, Tuple, Optional

class LaneDisciplineRule:
    def __init__(self, max_lateral_drift_px: float = 85.0, max_cached_ids: int = 1000):
        self.max_lateral_drift_px = max_lateral_drift_px
        self.max_cached_ids = max_cached_ids
        self.trajectory_history: Dict[int, list] = {}  # track_id -> [(cx, cy), ...]
        self.penalized_ids = set()

    def check_swerve(self, track_id: int, bbox: Tuple[int, int, int, int]) -> Optional[dict]:
        if track_id == -1 or track_id in self.penalized_ids:
            return None

        x1, y1, x2, y2 = bbox
        cx = (x1 + x2) / 2.0
        cy = (y1 + y2) / 2.0

        if track_id not in self.trajectory_history:
            self.trajectory_history[track_id] = []
        
        history = self.trajectory_history[track_id]
        history.append((cx, cy))

        if len(history) > 15:
            history.pop(0)

        # Look for sudden violent lateral displacement (swerving) over 5-8 frames
        if len(history) >= 8:
            old_cx = history[0][0]
            curr_cx = history[-1][0]
            drift = abs(curr_cx - old_cx)

            if drift > self.max_lateral_drift_px:
                self.penalized_ids.add(track_id)
                return {
                    "rule": "SUDDEN_SWERVING",
                    "detail": f"Sudden lane deviation: lateral drift {int(drift)}px exceeds safety threshold"
                }

        return None
