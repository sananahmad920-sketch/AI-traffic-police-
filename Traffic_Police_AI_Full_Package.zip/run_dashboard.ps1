# PowerShell launcher for Smart Traffic Police AI Dashboard
$CurrentDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $CurrentDir
Write-Host "========================================================" -ForegroundColor Cyan
Write-Host "  SMART TRAFFIC POLICE AI: CAMERA VIOLATION DETECTOR" -ForegroundColor Yellow
Write-Host "========================================================" -ForegroundColor Cyan
& ".\.venv\Scripts\python.exe" -m streamlit run app.py --server.port 8501 --server.headless true
