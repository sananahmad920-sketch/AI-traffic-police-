"""
Distributed Storage Client supporting S3 / MinIO Object Storage
with automatic local directory fallback for offline and standalone deployments.
Computes tamper-evident SHA-256 hashes at upload time.
"""
import io
import os
import hashlib
from pathlib import Path
from typing import Tuple, Optional
from service_config import settings
from logger import get_logger

logger = get_logger("StorageService")

class StorageService:
    def __init__(self):
        self.minio_client = None
        self.bucket_name = settings.MINIO_BUCKET_NAME
        self.local_dir = settings.LOCAL_STORAGE_DIR
        self.local_dir.mkdir(parents=True, exist_ok=True)
        
        self._init_minio()

    def _init_minio(self):
        try:
            from minio import Minio
            self.minio_client = Minio(
                settings.MINIO_ENDPOINT,
                access_key=settings.MINIO_ACCESS_KEY,
                secret_key=settings.MINIO_SECRET_KEY,
                secure=settings.MINIO_SECURE
            )
            # Verify bucket
            if not self.minio_client.bucket_exists(self.bucket_name):
                self.minio_client.make_bucket(self.bucket_name)
            logger.info(f"Connected to MinIO/S3 object store at {settings.MINIO_ENDPOINT}, bucket '{self.bucket_name}'.")
        except Exception as e:
            logger.warning(f"MinIO/S3 not reachable ({e}). Falling back to local storage path: {self.local_dir}")
            self.minio_client = None

    def store_evidence(self, file_bytes: bytes, object_name: str, content_type: str = "image/jpeg") -> Tuple[str, str]:
        """
        Stores image/video in MinIO or local filesystem.
        Returns: (storage_uri, sha256_hash)
        """
        # Compute tamper-evident cryptographic hash
        sha256_hash = hashlib.sha256(file_bytes).hexdigest()

        # Try MinIO/S3
        if self.minio_client is not None:
            try:
                data_stream = io.BytesIO(file_bytes)
                self.minio_client.put_object(
                    self.bucket_name,
                    object_name,
                    data_stream,
                    length=len(file_bytes),
                    content_type=content_type
                )
                uri = f"s3://{self.bucket_name}/{object_name}"
                logger.info(f"Stored evidence in S3/MinIO: {uri} (SHA256: {sha256_hash[:12]}...)")
                return uri, sha256_hash
            except Exception as e:
                logger.warning(f"Failed to write to MinIO ({e}). Falling back to local disk.")

        # Local storage fallback
        local_path = self.local_dir / object_name
        local_path.parent.mkdir(parents=True, exist_ok=True)
        with open(local_path, "wb") as f:
            f.write(file_bytes)
        
        logger.info(f"Stored evidence locally: {local_path} (SHA256: {sha256_hash[:12]}...)")
        return str(local_path), sha256_hash

storage_service = StorageService()
