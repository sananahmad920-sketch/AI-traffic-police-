"""
Hardened Red Light & Stop-Line Violation Detection Rule.
Includes bounded memory caching to prevent memory leaks during long-running surveillance.
"""
from typing import Dict, Tuple, Optional

class RedLightRule:
    def __init__(self, stop_line_y: int = 260, max_cached_ids: int = 1000):
        self.stop_line_y = stop_line_y
        self.max_cached_ids = max_cached_ids
        self.prev_positions: Dict[int, float] = {}
        self.penalized_ids = set()

    def update_stop_line(self, y: int):
        self.stop_line_y = y

    def _prune_cache_if_needed(self):
        """Prevent unbounded memory growth during continuous 24/7 surveillance."""
        if len(self.prev_positions) > self.max_cached_ids:
            # Drop oldest 30% of keys
            old_keys = list(self.prev_positions.keys())[:int(self.max_cached_ids * 0.3)]
            for k in old_keys:
                del self.prev_positions[k]
                self.penalized_ids.discard(k)

    def check_violation(
        self,
        track_id: int,
        bbox: Tuple[int, int, int, int],
        is_red_signal: bool
    ) -> Optional[dict]:
        """
        Check if the vehicle crossed the stop line while the signal is red.
        bbox is (x1, y1, x2, y2).
        """
        if track_id in self.penalized_ids:
            return None

        self._prune_cache_if_needed()

        x1, y1, x2, y2 = bbox
        current_y = float(y2)
        prev_y = self.prev_positions.get(track_id, current_y)
        self.prev_positions[track_id] = current_y

        # Vehicle moved across the line from top to bottom (entering intersection)
        crossed_line = (prev_y < self.stop_line_y) and (current_y >= self.stop_line_y)

        if crossed_line and is_red_signal:
            self.penalized_ids.add(track_id)
            return {
                "rule": "RED_LIGHT_VIOLATION",
                "detail": f"Vehicle crossed stop line (y={self.stop_line_y}) during RED signal",
                "track_id": track_id,
                "bbox": bbox
            }

        return None
