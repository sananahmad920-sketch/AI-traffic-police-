"""
Unified Multi-Service Node Orchestrator.
Can run in:
- Ingest Mode (--role ingest): Handles sharded RTSP stream decoding
- Inference Mode (--role inference): Runs YOLOv8 + ByteTrack + Traffic Rules
- API Mode (--role api): Runs FastAPI event service
- Standalone / Edge Mode (--role all): Autonomous complete station on a single GPU node
"""
import sys
import time
import argparse
import signal
import uvicorn
from pathlib import Path

CURRENT_DIR = Path(__file__).resolve().parent
if str(CURRENT_DIR) not in sys.path:
    sys.path.append(str(CURRENT_DIR))

from logger import get_logger
from service_config import settings
from frame_queue import BoundedFrameQueue
from ingest_worker import CameraStreamIngestWorker
from inference_worker import InferenceWorker
from camera_scheduler import scheduler
from event_service import app

logger = get_logger("NodeOrchestrator")

def run():
    parser = argparse.ArgumentParser(description="Smart Traffic Police Microservice Node Orchestrator")
    parser.add_argument("--role", choices=["all", "ingest", "inference", "api"], default="all", help="Service role for this container or VM")
    parser.add_argument("--node-id", type=str, default="node-01", help="Unique identifier for this cluster node")
    parser.add_argument("--sources", nargs="*", default=["CAM-01=traffic_cctv.mp4"], help="Camera stream definitions (e.g. CAM-01=rtsp://...)")
    parser.add_argument("--api-port", type=int, default=8000, help="Port for event API")
    args = parser.parse_args()

    logger.info(f"Starting Node Orchestrator (Node ID: {args.node_id}, Role: {args.role.upper()})")

    frame_queue = BoundedFrameQueue(maxsize=settings.MAX_QUEUE_SIZE, worker_id=args.node_id)
    ingest_workers = []
    inference_worker = None

    running = True
    def shutdown(sig, frame):
        nonlocal running
        logger.info("Shutdown signal received. Stopping worker threads cleanly...")
        running = False
        for iw in ingest_workers:
            iw.stop()
        if inference_worker:
            inference_worker.stop()

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    # 1. Start Ingest Workers
    if args.role in ["all", "ingest"]:
        for s_def in args.sources:
            if "=" in s_def:
                cid, src = s_def.split("=", 1)
            else:
                cid, src = f"CAM-{len(ingest_workers)+1:02d}", s_def
            
            # Local video file resolution
            if not src.startswith("rtsp://") and not src.isdigit() and not Path(src).is_absolute():
                src = str(CURRENT_DIR / src)

            iw = CameraStreamIngestWorker(
                camera_id=cid,
                rtsp_url=src,
                output_queue=frame_queue,
                target_fps=settings.DEFAULT_SAMPLING_FPS
            )
            iw.start()
            ingest_workers.append(iw)

    # 2. Start Inference Workers
    if args.role in ["all", "inference"]:
        inference_worker = InferenceWorker(
            worker_id=args.node_id,
            input_queue=frame_queue
        )
        inference_worker.start()

    # 3. Start API Service
    if args.role in ["all", "api"]:
        import threading
        api_thread = threading.Thread(
            target=lambda: uvicorn.run(app, host=settings.API_HOST, port=args.api_port, log_level="warning"),
            name="API-Server",
            daemon=True
        )
        api_thread.start()
        logger.info(f"FastAPI Event Service listening on http://{settings.API_HOST}:{args.api_port}")

    logger.info("All configured subsystems active and healthy.")

    while running:
        time.sleep(1.0)

    logger.info("Orchestrator shutdown complete.")

if __name__ == "__main__":
    run()
