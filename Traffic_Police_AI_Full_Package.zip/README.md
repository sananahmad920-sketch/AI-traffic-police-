# 🚔 Smart Traffic Police AI: Enterprise Production Deployment

An automated, tamper-evident Computer Vision system designed to monitor multiple traffic camera streams (CCTV, RTSP, recorded MP4/AVI files, or webcams), identify vehicles, catch traffic rule violations, read license plates (ANPR), and log photo evidence with SHA-256 cryptographic hashes into a PostgreSQL database.

---

## 🌟 Key Upgraded Infrastructure Capabilities

1. **🔒 PostgreSQL Tamper-Evident Storage:**
   - Violation records are stored in PostgreSQL with exact timestamp, camera ID, license plate, violation type, file path, and a **SHA-256 cryptographic hash** computed at capture time to prevent digital evidence tampering in legal disputes.
   - Includes automatic SQLite fallback if running offline without a PostgreSQL server.

2. **📹 Resilient Multi-Camera Architecture:**
   - Each camera feed runs in its own isolated background worker thread.
   - **Exponential Backoff Reconnect:** If an RTSP stream drops or camera network hiccups, the worker automatically retries (2s, 4s, 8s... up to 60s) without blocking or crashing other cameras or the web dashboard.
   - Easily add and remove camera streams on the fly via UI or CLI.

3. **🛡️ Authentication & Audit Logging:**
   - Secure login screen with **bcrypt** password hashing.
   - Every login attempt, logout, surveillance monitoring session, and evidence photo access is logged with timestamp, user ID, client IP, and action into `auth_audit_logs`.

4. **🚀 Production Containerization:**
   - Pinned `requirements.txt` ensuring exact dependencies.
   - Production `Dockerfile` and `docker-compose.yml` for 1-click deployment with a dedicated PostgreSQL database container.
   - Streamlit configured to bind to `0.0.0.0` for intranet and remote police terminal access.
   - Rotating file logging in `logs/traffic_police_ai.log`.

---

## 🐳 How to Run with Docker (Recommended for Production)

### 1. Prerequisites
- Install **Docker** and **Docker Compose** on the server.

### 2. Start Services
From the project directory, run:
```bash
docker compose up -d --build
```
This automatically starts:
* `traffic_police_db`: PostgreSQL 15 container initialized with tables.
* `traffic_police_ai`: Python 3.11 AI application binding on port `8501`.

### 3. Open the Dashboard
Navigate to:
```text
http://<SERVER_IP>:8501
```
* **Default Admin Credentials:**
  * Username: `admin`
  * Password: `policeadmin123`
* **Default Officer Credentials:**
  * Username: `officer1`
  * Password: `officerpass`

### 4. Stop Services
```bash
docker compose down
```

---

## ⚙️ Environment Variables

Configure these in your `docker-compose.yml` or `.env` file:

| Variable | Description | Example |
| :--- | :--- | :--- |
| `DATABASE_URL` | PostgreSQL connection URL | `postgresql://user:password@localhost:5432/traffic_police` |
| `DEFAULT_ADMIN_PASSWORD` | Initial password for the admin account | `policeadmin123` |
| `DEFAULT_OFFICER_PASSWORD`| Initial password for the officer account | `officerpass` |
| `RTSP_CAMERA_01` | RTSP URL for Junction 1 camera | `rtsp://admin:pass@192.168.1.101:554/stream` |
| `RTSP_CAMERA_02` | RTSP URL for Junction 2 camera | `rtsp://admin:pass@192.168.1.102:554/stream` |

---

## 📹 How to Add & Remove Camera Feeds

### Method 1: Via the Web Dashboard (Live at Runtime)
1. Log into the command center at `http://<SERVER_IP>:8501`.
2. In the left sidebar, expand **"➕ Add New Camera Feed"**.
3. Enter:
   * **Camera ID:** e.g., `CAM-04`
   * **Location Name:** e.g., `5th Ave Crossing`
   * **RTSP URL / Source:** e.g., `rtsp://admin:12345@192.168.1.104:554/stream`
4. Click **"Connect Feed"**. The feed immediately launches in an isolated worker thread.
5. To remove a feed, switch to the **"📊 System Health"** tab, expand **"🗑️ Manage Camera Feeds"**, select the camera, and click **"Stop & Remove Camera"**.

### Method 2: Via 24/7 Headless Daemon CLI (Without Browser)
You can run the multi-camera background daemon on any number of camera feeds simultaneously:
```bash
python surveillance_service.py \
  --sources "CAM-01=rtsp://admin:pass@192.168.1.101:554/live" "CAM-02=rtsp://admin:pass@192.168.1.102:554/live" \
  --speed-limit 50 \
  --stop-line 260
```

---

## 📁 Project Structure

```text
traffic-violation-detector/
│
├── app.py                     # Enterprise Streamlit Command Center (Auth + Multi-Cam)
├── auth.py                    # Bcrypt authentication and user session management
├── database.py                # PostgreSQL / SQLite manager with SHA-256 and audit logs
├── camera_manager.py          # Threaded RTSP stream workers with exponential backoff
├── processor.py               # Video processing pipeline with camera_id tagging
├── detector.py                # Core YOLOv8 object detector & ByteTrack tracker (Untouched)
├── anpr.py                    # Asynchronous license plate reader
├── evidence.py                # Evidence generator with SHA-256 cryptographic hashing
├── logger.py                  # Rotating file & console logging (logs/traffic_police_ai.log)
│
├── requirements.txt           # Pinned production Python dependencies
├── Dockerfile                 # Production container image definition
├── docker-compose.yml         # Compose stack with PostgreSQL & AI service
│
├── rules/                     # Violation detection rules (Red light, Speed, Helmet, Wrong-way)
├── violations/                # Saved JPEG evidence cards with SHA-256 hashes
└── logs/                      # System and audit rotating logs
```

---

## 🛡️ Tamper-Evidence Verification

Each violation stored in the database includes a `sha256_hash` field computed at the exact moment of capture:
* To verify an evidence photo hasn't been altered, select it in the **"📋 Challan Records & Search"** tab.
* The system displays the original cryptographic hash. You can independently verify the hash on Linux/Mac with:
  ```bash
  sha256sum violations/VIOL-xxx.jpg
  ```
  or on Windows PowerShell:
  ```powershell
  Get-FileHash violations\VIOL-xxx.jpg -Algorithm SHA256
  ```
