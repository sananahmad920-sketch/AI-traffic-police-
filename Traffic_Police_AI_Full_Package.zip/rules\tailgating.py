"""
Dubai Police Smart Traffic Rule: Safe Distance / Tailgating Detection.
Detects when two vehicles traveling in the same lane are dangerously close
at speed, a major automated fine category on Dubai highways (AED 400 + 4 black points).
"""
import time
from typing import Dict, List, Tuple, Optional

class TailgatingRule:
    def __init__(self, min_safe_gap_meters: float = 8.0, pixels_per_meter: float = 8.5, speed_threshold_kmh: float = 30.0):
        self.min_safe_gap_meters = min_safe_gap_meters
        self.pixels_per_meter = pixels_per_meter
        self.speed_threshold_kmh = speed_threshold_kmh
        self.penalized_pairs = set()

    def check_tailgating(self, vehicles: List[dict]) -> List[dict]:
        """
        Scans vehicles moving in the same corridor and flags tailgaters.
        """
        violations = []
        if len(vehicles) < 2:
            return violations

        # Sort by vertical position (y2 - bottom of vehicle)
        sorted_v = sorted(vehicles, key=lambda v: v["bbox"][3])

        for i in range(len(sorted_v) - 1):
            lead = sorted_v[i]
            tail = sorted_v[i + 1]

            lead_id = lead.get("track_id", -1)
            tail_id = tail.get("track_id", -1)

            if lead_id == -1 or tail_id == -1:
                continue

            pair_key = (tail_id, lead_id)
            if pair_key in self.penalized_pairs:
                continue

            # Check horizontal lane alignment (overlapping X ranges)
            lx1, ly1, lx2, ly2 = lead["bbox"]
            tx1, ty1, tx2, ty2 = tail["bbox"]

            x_overlap = min(lx2, tx2) - max(lx1, tx1)
            lead_w = max(1, lx2 - lx1)
            tail_w = max(1, tx2 - tx1)

            # In same lane if significant horizontal overlap
            if x_overlap > 0.4 * min(lead_w, tail_w):
                # Vertical gap between front of tail vehicle and rear of lead vehicle
                pixel_gap = max(0, ty1 - ly2)
                meter_gap = pixel_gap / self.pixels_per_meter

                if meter_gap < self.min_safe_gap_meters:
                    self.penalized_pairs.add(pair_key)
                    violations.append({
                        "rule": "TAILGATING_VIOLATION",
                        "tail_id": tail_id,
                        "lead_id": lead_id,
                        "gap_meters": round(meter_gap, 1),
                        "detail": f"Unsafe following distance: {round(meter_gap, 1)}m (Dubai standard min: {self.min_safe_gap_meters}m)"
                    })

        return violations
